package board.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import DBUtil.DBConn;
import board.dto.Board;

public class BoardDaoImpl implements BoardDao {

	// DB 연결 객체
	private Connection conn = DBConn.getConnection();
	
	// JDBC 객체
	private PreparedStatement ps;
	private ResultSet rs;
	
	@Override
	public List selectAll() {
		
		// 전체조회 쿼리
		String sql =
				"SELECT" + 
				"    boardno," + 
				"    title," + 
				"    writerid," + 
				"    writer," + 
				"    content," + 
				"    hit," + 
				"    recommend," + 
				"    writtendate" + 
				" FROM board" + 
				" ORDER BY boardno";
		
		// 결과 List
		List boardList = new ArrayList();
		try {
			// PreparedStatement 생성
			ps = conn.prepareStatement(sql);
			
			// ResultSet 반환
			rs = ps.executeQuery();
			
			while( rs.next() ) {
				Board board = new Board();
				
				board.setBoardno( rs.getInt("boardno") );
				board.setTitle( rs.getString("title") );
				board.setWriterid( rs.getString("writerid") );
				board.setWriter( rs.getString("writer") );
				board.setContent( rs.getString("content") );
				board.setHit( rs.getInt("hit") );
				board.setRecommend( rs.getInt("recommend") );
				board.setWrittendate( rs.getDate("writtendate") );
				
				boardList.add(board);
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				if(rs!=null)	rs.close();
				if(ps!=null)	ps.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			
		}
		
		return boardList;
	}

}











