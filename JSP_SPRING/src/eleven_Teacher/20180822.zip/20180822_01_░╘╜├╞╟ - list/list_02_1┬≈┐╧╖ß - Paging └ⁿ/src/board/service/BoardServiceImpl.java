package board.service;

import java.util.List;

import board.dao.BoardDao;
import board.dao.BoardDaoImpl;

public class BoardServiceImpl implements BoardService {

	private BoardDao boardDao = new BoardDaoImpl();
	
	@Override
	public List getList() {
		return boardDao.selectAll();
	}

}









