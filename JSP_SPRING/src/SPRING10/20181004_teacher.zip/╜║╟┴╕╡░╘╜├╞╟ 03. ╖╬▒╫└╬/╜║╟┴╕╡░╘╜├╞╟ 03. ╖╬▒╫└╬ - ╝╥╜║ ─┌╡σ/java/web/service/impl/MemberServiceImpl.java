package web.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import web.dao.face.MemberDao;
import web.dto.Member;
import web.service.face.MemberService;

@Service
public class MemberServiceImpl implements MemberService {
	@Autowired MemberDao memberDao;

	@Override
	public void join(Member member) {
		if( memberDao.selectCntById(member) > 0 )	return;

		memberDao.insert(member);
	}

	@Override
	public boolean login(Member member) {
		if( memberDao.selectCnt(member) == 1 )	return true;
		else	return false;
		
	}

	@Override
	public Member info(Member member) {
		return memberDao.select(member);
	}
	
	
}
