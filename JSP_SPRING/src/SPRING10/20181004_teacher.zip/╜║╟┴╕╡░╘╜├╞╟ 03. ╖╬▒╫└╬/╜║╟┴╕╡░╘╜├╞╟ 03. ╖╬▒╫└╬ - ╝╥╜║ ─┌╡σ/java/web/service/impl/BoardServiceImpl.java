package web.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import web.dao.face.BoardDao;
import web.service.face.BoardService;
import web.util.Paging;

@Service
public class BoardServiceImpl implements BoardService {

	@Autowired private BoardDao boardDao;

	@Override
	public List list(Paging paging) {
		return boardDao.selectPagingList(paging);
	}

	@Override
	public Paging getPaging(int curPage, int listCount, int pageCount) {

		int totalCount = this.selectCountAll();
		
		Paging paging = new Paging(totalCount, curPage, listCount, pageCount);
		
		return paging;
	}

	@Override
	public int selectCountAll() {
		return boardDao.selectCntAll();
	}
	
}
