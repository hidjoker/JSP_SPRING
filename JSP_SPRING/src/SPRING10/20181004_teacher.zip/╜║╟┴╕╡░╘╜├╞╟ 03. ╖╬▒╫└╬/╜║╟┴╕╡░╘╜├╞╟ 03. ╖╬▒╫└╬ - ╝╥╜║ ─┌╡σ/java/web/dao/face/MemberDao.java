package web.dao.face;

import web.dto.Member;

public interface MemberDao {
	
	//존재하는 아이디인지 확인
	public int selectCntById(Member member);
	
	//존재하는 아이디/패스인지 확인
	public int selectCnt(Member member);
	
	//회원정보 삽입
	public void insert(Member member);
	
	//회원정보 조회
	public Member select(Member member);
	
}
