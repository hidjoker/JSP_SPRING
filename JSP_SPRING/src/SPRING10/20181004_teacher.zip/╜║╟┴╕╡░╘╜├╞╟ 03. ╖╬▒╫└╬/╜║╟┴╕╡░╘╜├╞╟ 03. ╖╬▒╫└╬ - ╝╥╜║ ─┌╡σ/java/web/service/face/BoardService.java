package web.service.face;

import java.util.List;

import web.util.Paging;

public interface BoardService {
	
	//게시글 전체 목록
	public List list(Paging paging);

	//게시글 전체 수 반환
	public int selectCountAll();
	
	//페이징 정보 만들기
	public Paging getPaging(int curPage, int listCount, int pageCount);
	
	
}
