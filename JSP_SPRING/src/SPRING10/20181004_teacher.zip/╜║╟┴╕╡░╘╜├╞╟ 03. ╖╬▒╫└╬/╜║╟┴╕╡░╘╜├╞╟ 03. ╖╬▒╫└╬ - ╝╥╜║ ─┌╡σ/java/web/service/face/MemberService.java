package web.service.face;

import web.dto.Member;

public interface MemberService {
	
	//회원가입
	public void join(Member member);
	
	//로그인
	public boolean login(Member member);
	
	//회원정보 얻기
	public Member info(Member member);
	
}
