package web.dao.face;

import java.util.List;

import web.util.Paging;

public interface BoardDao {
	
	//전체 조회
	public List selectPagingList(Paging paging);
	
	//전체 게시글 수 조회
	public int selectCntAll();
	
}
