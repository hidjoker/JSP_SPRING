package web.controller;

import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import web.dto.Member;
import web.service.face.MemberService;

@Controller
public class MemberController {
	
	private static final Logger logger = LoggerFactory.getLogger(MemberController.class);
	
	@Autowired private MemberService memberService;
	
	@RequestMapping(value="/member/main", method=RequestMethod.GET)
	public void main() {
		
	}

	@RequestMapping(value="/member/join", method=RequestMethod.GET)
	public void join() {
		
	}

	@RequestMapping(value="/member/join", method=RequestMethod.POST)
	public String joinProcess(Member member) {
		memberService.join(member);
		
		return "redirect:/member/main";
	}
	
	@RequestMapping(value="/member/login", method=RequestMethod.GET)
	public void login() {
		
	}

	@RequestMapping(value="/member/login", method=RequestMethod.POST)
	public String loginProcess(HttpSession session, Member member) {
		if( memberService.login(member) ) {
			member = memberService.info(member);
			
			session.setAttribute("login", true);
			session.setAttribute("id", member.getId());
			session.setAttribute("nick", member.getNick());
		}
		
		return "redirect:/member/main";
	}

	@RequestMapping(value="/member/logout", method=RequestMethod.GET)
	public String logout(HttpSession session) {
		session.invalidate();
		
		return "redirect:/member/main";
	}
}












