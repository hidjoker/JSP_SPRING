package web.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class InterceptorAdminController {
	private static final Logger logger
		= LoggerFactory.getLogger(InterceptorAdminController.class);
	
	@RequestMapping(value="/interceptor/admin/main")
	public void adminMain() {
		logger.info("관리자 메인 페이지 활성화");
	}
	
	@RequestMapping(value="/interceptor/admin/adminFail")
	public void adminFail() {
		logger.info("관리자 페이지 접속 실패");
	}
	
}
