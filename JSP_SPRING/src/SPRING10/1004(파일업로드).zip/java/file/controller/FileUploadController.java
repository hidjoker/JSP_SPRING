package file.controller;

import java.io.File;
import java.io.IOException;
import java.util.UUID;

import javax.servlet.ServletContext;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.multipart.MultipartFile;

@Controller
public class FileUploadController {

	@Autowired ServletContext context;
	
	@RequestMapping(value="/file/fileupload", method=RequestMethod.GET)
	public void fileForm() {
		
	}
	
	@RequestMapping(value="/file/fileupload", method=RequestMethod.POST)
	public void fileProcess(MultipartFile file) {
//		System.out.println(file);
//		System.out.println(file.getName());
//		System.out.println(file.getOriginalFilename());
//		System.out.println(file.getSize());
//		System.out.println(file.getContentType());
				
		// --- DB 정보 ---
		// fileno - 시퀀스로 자동 부여
		// origin_name - getOriginalFilename()
		// stored_name - getOriginalFilename() + UUID
		// file_size - getSize()
		// upload_date - 디폴트로 자동 부여
	
		String realpath = context.getRealPath("upload");
		
		String uid = UUID.randomUUID().toString().split("-")[4];
		
		String stored = file.getOriginalFilename()+"_"+uid;
		File dest = new File(realpath, stored);
		
		try {
			file.transferTo(dest);
		} catch (IllegalStateException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		
		
	}	
}
