package file.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import file.dao.FileTestDao;
import file.dto.FileTest;

@Service
public class FileTestServiceImpl implements FileTestService{

	private @Autowired FileTestDao dao;
	
	private static Logger logger
		= LoggerFactory.getLogger(FileTestServiceImpl.class);
	
	@Override
	public void insertFile(FileTest test) {
		dao.insertFile(test);		
	}

}
