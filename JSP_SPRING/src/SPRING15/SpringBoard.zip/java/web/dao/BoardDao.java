package web.dao;

import java.util.List;

import web.dto.Board;
import web.dto.Comment;
import web.dto.Paging;

public interface BoardDao {

	public int totalCnt();
	
	public List<Board> list(Paging paging);
	
	public Board select(Board board);
	
	public void hit(Board board);
	
	public void write(Board board);
	
	public void updateBoard(Board board);
	
	public void deleteBoard(Board board);
	
	public List<Comment> selectCommentByBoardNo(Board board);
	
	public void insertComment(Comment comment);
	
	public void deleteComment(Comment comment);
	
	public Comment commentByCommentNo(Comment comment);
	
}
