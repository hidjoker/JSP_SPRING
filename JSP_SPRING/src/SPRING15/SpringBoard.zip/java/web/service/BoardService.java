package web.service;

import java.util.List;

import web.dto.Board;
import web.dto.Comment;
import web.dto.Paging;

public interface BoardService {

	public int totalCnt();
	
	public List<Board> list(Paging paging);
	
	public Board view(Board board);
	
	public void write(Board board);
	
	public void updateBoard(Board board);
	
	public void deleteBoard(Board board);
	
	public List<Comment> commentList(Board board);
	
	public void commentDelete(Comment comment);
	
	public void commentInsert(Comment comment);
	
	public Comment commentByCommentNo(Comment comment);
	
}
