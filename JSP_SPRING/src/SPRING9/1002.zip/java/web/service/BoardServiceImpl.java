package web.service;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import web.controller.BoardController;
import web.dao.BoardDao;
import web.dto.Board;
import web.dto.Paging;

@Service
public class BoardServiceImpl implements BoardService{

	private static Logger logger
	= LoggerFactory.getLogger(BoardController.class);

	@Autowired private BoardDao dao;
	
	@Override
	public int totalCnt() {
		int total = dao.totalCnt();
		return total;
	}
	
	@Override
	public List<Board> list(Paging paging) {
		List list = dao.list(paging);
		return list;
	}


	
	
	
}
