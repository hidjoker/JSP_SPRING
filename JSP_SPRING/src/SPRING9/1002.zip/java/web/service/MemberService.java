package web.service;

import web.dto.Member;

public interface MemberService {

	public void join(Member member);
	
	public int search(Member member);
	
	public Member select(Member member);
	
}
