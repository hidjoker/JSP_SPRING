package web.service;


import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import web.dao.MemberDao;
import web.dto.Member;

@Service
public class MemberServiceImpl implements MemberService{
	
	private static Logger logger
		= LoggerFactory.getLogger(MemberServiceImpl.class);

	@Autowired
	private MemberDao dao;
	
	@Override
	public void join(Member member) {
		dao.join(member);
	}

	@Override
	public int search(Member member) {
		return dao.search(member);
	}

	@Override
	public Member select(Member member) {
		return dao.select(member);
	}
	
	

}
