package web.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import web.dto.Board;
import web.dto.Paging;
import web.service.BoardServiceImpl;

@Controller
public class BoardController {
	
	private static Logger logger
		= LoggerFactory.getLogger(BoardController.class);
	
	@Autowired
	private BoardServiceImpl service;
	
	@RequestMapping(value="/board/list", method=RequestMethod.GET)
	public void list(HttpServletRequest req,Model m) {
		
		logger.info("들어옴");
		// 현재 페이지 
		String param = req.getParameter("curPage");
		
		int curPage = 0;
		if( !"".equals(param) && param != null ) {
			curPage = Integer.parseInt(
				req.getParameter("curPage") );
		}
		// 총 게시글 수
		int totalCount = service.totalCnt();
		
		Paging paging = new Paging(totalCount,curPage);
		logger.info("startNo : "+paging.getStartNo());
		logger.info("startNo : "+paging.getEndNo());
		List<Board> list = service.list(paging);
		m.addAttribute("list",list);	
		m.addAttribute("paging",paging);
	}

}
