package web.dao;

import java.util.List;

import web.dto.Board;
import web.dto.Paging;

public interface BoardDao {

	public int totalCnt();
	
	public List<Board> list(Paging paging);
}
