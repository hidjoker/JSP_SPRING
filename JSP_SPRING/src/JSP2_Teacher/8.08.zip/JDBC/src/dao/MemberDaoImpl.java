package dao;

import dto.Member;

public class MemberDaoImpl implements MemberDao {

	// 회원가입 처리 메소드
	@Override
	public boolean join(Member insertMember) {
		
		return false;
	}

}











