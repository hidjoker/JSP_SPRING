package board.dao;

import board.dto.Board;
import board.dto.UpFile;

public interface UpFileDao {
	
	// 첨부파일 업로드
	public void insert(UpFile file);
	
	// 첨부파일 조회
	public UpFile selectFileByBoardno(Board board);
	
}
