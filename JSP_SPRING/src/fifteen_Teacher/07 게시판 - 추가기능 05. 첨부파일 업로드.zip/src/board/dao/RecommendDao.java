package board.dao;

import board.dto.Board;

public interface RecommendDao {

	// 추천 수 구하기
	public int selectCountRecommend(Board board);
	
	// 추천 넣기 
	public void insertRecommend(Board board);
	
	// 추천 삭제
	public void deleteRecommend(Board board);
	
	// 총 추천 수 구하기
	public int selectTotalRecommend(Board board);
}
