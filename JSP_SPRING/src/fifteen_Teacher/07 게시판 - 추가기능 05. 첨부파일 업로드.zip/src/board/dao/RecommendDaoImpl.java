package board.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import DBUtil.DBConn;
import board.dto.Board;

public class RecommendDaoImpl implements RecommendDao {

	// DB 연결 객체
	private Connection conn = DBConn.getConnection();
	
	// JDBC 객체
	private PreparedStatement ps;
	private ResultSet rs;

	@Override
	public int selectCountRecommend(Board board) {

		String sql = "SELECT COUNT(*) FROM recommend"
				+ " WHERE userid=?"
				+ " AND boardno=?";
		
		int cnt = 0;
		
		try {
			ps = conn.prepareStatement(sql);
			ps.setString(1, board.getWriterid());
			ps.setInt(2, board.getBoardno());
			
			rs = ps.executeQuery();
			
			while(rs.next()) {
				cnt = rs.getInt(1);
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				rs.close();
				ps.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		
		return cnt;
	}

	@Override
	public void insertRecommend(Board board) {
		String sql = "INSERT INTO recommend (userid, boardno)"
				+ " VALUES( ?, ? )";
		
		try {
			ps = conn.prepareStatement(sql);
			ps.setString(1, board.getWriterid());
			ps.setInt(2, board.getBoardno());
			
			ps.executeUpdate();
			
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				rs.close();
				ps.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}

	@Override
	public void deleteRecommend(Board board) {
		String sql = "DELETE recommend"
				+ " WHERE userid=?"
				+ "	AND boardno=?";
		
		try {
			ps = conn.prepareStatement(sql);
			ps.setString(1, board.getWriterid());
			ps.setInt(2, board.getBoardno());
			
			ps.executeUpdate();
			
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				rs.close();
				ps.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}

	@Override
	public int selectTotalRecommend(Board board) {
		String sql = "SELECT COUNT(*) FROM recommend"
				+ " WHERE boardno=?";
		
		int cnt = 0;
		
		try {
			ps = conn.prepareStatement(sql);
			ps.setInt(1, board.getBoardno());
			
			rs = ps.executeQuery();
			
			while(rs.next()) {
				cnt = rs.getInt(1);
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				rs.close();
				ps.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		
		return cnt;
	}

}
