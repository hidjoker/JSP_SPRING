package board.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import DBUtil.DBConn;
import board.dto.Board;
import board.dto.UpFile;

public class UpFileDaoImpl implements UpFileDao {
	
	// DB 연결 객체
	private Connection conn = DBConn.getConnection();
	
	// JDBC 객체
	private PreparedStatement ps;
	private ResultSet rs;

	@Override
	public void insert(UpFile file) {
		String sql = "INSERT INTO upFile ( FILENO, BOARDNO, ORI_NAME, STO_NAME )" + 
				" VALUES ( SEQ_UPFILE.NEXTVAL, ?, ?, ? )";
		
		try {
			ps = conn.prepareStatement(sql);
			
			ps.setInt(1, file.getBoardno());
			ps.setString(2, file.getOri_name());
			ps.setString(3, file.getSto_name());
			ps.executeUpdate();
			
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				if(ps!=null)	ps.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}

	@Override
	public UpFile selectFileByBoardno(Board board) {
		// 전체조회 쿼리
		String sql =
			"SELECT"
			+ " 	FILENO,"
			+ " 	BOARDNO,"
			+ "		ORI_NAME,"
			+ " 	STO_NAME"
			+ "	FROM upFile"
			+ "	WHERE boardno = ?";
		
		UpFile file = new UpFile();
		try {
			ps = conn.prepareStatement(sql);
			ps.setInt(1, board.getBoardno());
			
			rs = ps.executeQuery();
			
			while( rs.next() ) {
				file.setFileno(rs.getInt("fileno"));
				file.setOri_name(rs.getString("ori_name"));
				file.setSto_name(rs.getString("sto_name"));
				
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				if(rs!=null)	rs.close();
				if(ps!=null)	ps.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			
		}
		
		return file;

	}
	
}
