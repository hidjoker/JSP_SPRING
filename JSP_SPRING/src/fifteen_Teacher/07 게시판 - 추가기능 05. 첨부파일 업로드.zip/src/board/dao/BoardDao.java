package board.dao;

import java.util.List;

import board.dto.Board;
import board.util.Paging;

public interface BoardDao {
	
	// board 테이블 전체 조회
	public List selectAll();
	
	// 총 게시글 수 조회
	public int selectCntAll();
	public int selectCntAllSearch(String search);
	
	// 페이징 리스트 조회
	public List selectPagingList(Paging paging);
	public List selectPagingListSearch(Paging paging);

	// 게시글 삽입
	public void insert(Board board);
	
	// 게시글 조회
	public Board selectBoardByBoardno(Board board);
	
	//  조회수 증가
	public void updateHit(Board board);
	
	// 게시글 수정
	public void update(Board board);

	// 게시글 삭제
	public void delete(Board board);

	
	
	// 리스트에서 게시글 삭제하기
	public void deleteBoardList(String names);
	
	
	
	// 게시글 번호 시퀀스에서 가져오기
	public int getBoardno();
	
}















