package board.dto;

import java.util.Date;

public class UpFile {

	private int fileno;
	private int boardno;
	private String ori_name;
	private String sto_name;
	private Date uploaddate;
	
	@Override
	public String toString() {
		return "UpFile [fileno=" + fileno + ", boardno=" + boardno + ", ori_name=" + ori_name + ", sto_name=" + sto_name
				+ ", uploaddate=" + uploaddate + "]";
	}
	
	public int getFileno() {
		return fileno;
	}
	public void setFileno(int fileno) {
		this.fileno = fileno;
	}
	public int getBoardno() {
		return boardno;
	}
	public void setBoardno(int boardno) {
		this.boardno = boardno;
	}
	public String getOri_name() {
		return ori_name;
	}
	public void setOri_name(String ori_name) {
		this.ori_name = ori_name;
	}
	public String getSto_name() {
		return sto_name;
	}
	public void setSto_name(String sto_name) {
		this.sto_name = sto_name;
	}
	public Date getUploaddate() {
		return uploaddate;
	}
	public void setUploaddate(Date uploaddate) {
		this.uploaddate = uploaddate;
	}
	
}
