package board.service;

import board.dao.MemberDao;
import board.dao.MemberDaoImpl;
import board.dto.User;

public class MemberServiceImpl implements MemberService {

	private MemberDao memberDao = new MemberDaoImpl(); 
	
	@Override
	public void join(User user) {
		memberDao.insert(user);		
	}

	@Override
	public boolean login(User user) {
		int cnt = memberDao.selectCntByIdAndPw(user);
		if(cnt > 0) {
			return true;
		} else {
			return false;
		}
	}

	@Override
	public String getNick(User user) {
		return memberDao.selectNickById(user);
	}

}
