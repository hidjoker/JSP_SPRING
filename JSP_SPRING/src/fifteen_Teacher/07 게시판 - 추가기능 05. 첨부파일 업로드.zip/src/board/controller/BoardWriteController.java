package board.controller;

import java.io.File;
import java.io.IOException;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.oreilly.servlet.MultipartRequest;
import com.oreilly.servlet.multipart.DefaultFileRenamePolicy;
import com.oreilly.servlet.multipart.FileRenamePolicy;

import board.dto.Board;
import board.dto.UpFile;
import board.service.BoardService;
import board.service.BoardServiceImpl;

@WebServlet("/board/write.do")
public class BoardWriteController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	private BoardService boardService = new BoardServiceImpl();
       
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.getRequestDispatcher("/board/write.jsp")
			.forward(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("UTF-8");
		
		
		ServletContext context = getServletContext();
		String saveDirectory = context.getRealPath("upload");
		int maxPostSize = 10 * 1024 * 1024; //10MB
		String encoding = "UTF-8";
		FileRenamePolicy policy
			= new DefaultFileRenamePolicy();

		MultipartRequest mul = new MultipartRequest(
				request,
				saveDirectory,
				maxPostSize,
				encoding,
				policy );
		
		
		
		
		Board board = new Board();
		board.setTitle(mul.getParameter("title"));
		board.setContent(mul.getParameter("content"));
		board.setWriterid((String) request.getSession().getAttribute("writerid")); 
		board.setWriter((String) request.getSession().getAttribute("writernick")); 
		
		
		

		File up = mul.getFile("file");
		System.out.println(up);
		
		if(up==null || !up.exists()) {
			boardService.write(board);
			
		} else {
			UpFile file = new UpFile();
			file.setBoardno(board.getBoardno());
			file.setOri_name(mul.getOriginalFileName("file"));
			file.setSto_name(mul.getFilesystemName("file"));
			
			boardService.write(board, file);
			
		}

		
		
	
		
		
		
		// 리다이렉트
		response.sendRedirect("/board/pagingList.do");
	}

}














