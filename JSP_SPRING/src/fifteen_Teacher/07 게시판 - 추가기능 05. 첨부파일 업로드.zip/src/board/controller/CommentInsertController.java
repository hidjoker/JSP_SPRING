package board.controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import board.dto.Comment;
import board.service.BoardService;
import board.service.BoardServiceImpl;

@WebServlet("/comment/insert.do")
public class CommentInsertController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	private BoardService boardService = new BoardServiceImpl();

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		request.setCharacterEncoding("UTF-8");
		
		Comment comment = new Comment();
		
		String boardNo = (String) request.getParameter("boardNo");
		String userid = (String) request.getParameter("userid");
		String commentWriter = (String) request.getParameter("commentWriter");
		String content = (String) request.getParameter("content");
		
		comment.setBoardNo( Integer.parseInt(boardNo) );
		comment.setUserid(userid);
		comment.setCommentWriter(commentWriter);
		comment.setContent(content);
		
		boardService.insertComment(comment);
		
		response.sendRedirect("/board/view.do?boardno="+comment.getBoardNo());
	}

}
