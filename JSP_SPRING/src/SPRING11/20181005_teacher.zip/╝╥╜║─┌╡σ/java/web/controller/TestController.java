package web.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class TestController {

	private Logger logger
		= LoggerFactory.getLogger(TestController.class);
	
	@RequestMapping(value="/test")
	public void Test() {
		logger.info("Test() 메소드 호출");
		
	}
}















