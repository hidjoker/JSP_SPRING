package file.dao;

import file.dto.Board;

public interface BoardDao {

	public Board selectFile(int fileno);
	
}
