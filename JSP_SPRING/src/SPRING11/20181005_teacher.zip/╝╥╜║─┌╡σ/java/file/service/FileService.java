package file.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import file.dao.BoardDao;
import file.dto.Board;

@Service
public class FileService {
	
	@Autowired BoardDao dao;
	
	public Board getFile(int fileno) {
		
		return dao.selectFile(fileno);
	}
	
}














