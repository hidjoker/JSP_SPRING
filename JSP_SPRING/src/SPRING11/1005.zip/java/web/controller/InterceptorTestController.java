package web.controller;

import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import web.dto.User;

@Controller
public class InterceptorTestController {

	private static final Logger logger 
		= LoggerFactory.getLogger(InterceptorTestController.class);
	
	@RequestMapping(value="/interceptor/main", method=RequestMethod.GET)
	public void main() {
		logger.info("메인 페이지 활성화");
	}
	
	@RequestMapping(value="interceptor/login", method=RequestMethod.GET)
	public void loginForm() {
		logger.info("로그인 폼 활성화");
	}
	
	@RequestMapping(value="interceptor/login", method=RequestMethod.POST)
	public String loginProcess(User user, HttpSession session) {
		logger.info("로그인 처리 활성화");
		logger.info(user.toString());
		
		if("abc".equals(user.getId())) {
			//일반 사용자
			logger.info("일반 사용자 로그인 성공");
			session.setAttribute("login", true);
			session.setAttribute("nick", "이마놀");
		}else if("admin".equals(user.getId())) {
			//관리자
			logger.info("관리자 로그인 성공");
			session.setAttribute("login", true);
			session.setAttribute("nick", "관리자");
		}else {
			//로그인 실패
			logger.info("로그인 실패");	
			return "redirect:/interceptor/login";
		}
		
		return "redirect:/interceptor/main";
	}
	
	@RequestMapping(value="/interceptor/logout")
	public String logout(HttpSession session) {
		logger.info("로그아웃 활성화");
		session.invalidate();
		return "redirect:/interceptor/main";
	}
}
