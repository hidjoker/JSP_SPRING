package web.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class BoardController {
	
	private static Logger logger
		= LoggerFactory.getLogger(BoardController.class);
	
	@RequestMapping(value="/board/list")
	public void list() {
		logger.info("목록 활성화");
	}
	@RequestMapping(value="/board/write")
	public void writeForm() {
		logger.info("글쓰기 활성화");
	}
	
	@RequestMapping(value="/board/noLogin")
	public void writeFail() {
		logger.info("글쓰기 페이지 접속 실패");
	}
	
}
