package file.dao;

import file.dto.FileTest;

public interface FileTestDao {

	public void insertFile(FileTest test);
	
	public FileTest getFile(FileTest file);
}
