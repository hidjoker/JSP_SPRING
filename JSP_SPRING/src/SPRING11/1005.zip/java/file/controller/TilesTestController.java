package file.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class TilesTestController {

	@RequestMapping(value="/main")
	public void excludemain() {
		// viewName : "main"
	}
	
	@RequestMapping(value="/test/main")
	public void main() {
		// viewName : "test/main"
	}
	
}
