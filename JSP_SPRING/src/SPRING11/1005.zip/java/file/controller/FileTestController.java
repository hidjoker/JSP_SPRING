package file.controller;

import java.io.File;
import java.io.IOException;
import java.util.UUID;

import javax.servlet.ServletContext;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;

import file.dto.FileTest;
import file.service.FileTestService;

@Controller
public class FileTestController {

	private @Autowired FileTestService service;
	
	private @Autowired ServletContext context;

	
	private static Logger logger
		= LoggerFactory.getLogger(FileTestController.class);
	
	
	@RequestMapping(value="/file/fileTest",method=RequestMethod.GET)
	public void fileTest() {}
	
	@RequestMapping(value="/file/fileTest",method=RequestMethod.POST)
	public void fileProc(MultipartFile file,FileTest test) {
		
		// --- DB 정보 ---
		// fileno - 시퀀스로 자동 부여
		// origin_name - getOriginalFilename()
		// stored_name - getOriginalFilename() + UUID
		// file_size - getSize()
		// upload_date - 디폴트로 자동 부여
		String uid = UUID.randomUUID().toString().split("-")[4];
		
		test.setOrigin_name(file.getOriginalFilename());
		test.setStored_name(file.getOriginalFilename()+uid);
		test.setFile_size(file.getSize());
		
		//파일 db저장
		service.insertFile(test);
		
		//파일 업로드
		String realpath = context.getRealPath("upload");
				
		String stored = test.getStored_name();
		File dest = new File(realpath, stored);
		
		try {
			file.transferTo(dest);
		} catch (IllegalStateException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		
	}
	
	@RequestMapping(value="/file/download")
	public ModelAndView download(int fileno) {
		//fileno로 파일의 정보 얻어오기
		FileTest file = new FileTest();
		file.setFileno(fileno);
		FileTest resFile =  service.getFile(file);
		
		//파일 원본이름 얻기
		String origin_name = resFile.getOrigin_name();
		
		System.out.println(resFile);
		
		ModelAndView mav = new ModelAndView();
		mav.setViewName("download");
		mav.addObject("downFile",resFile);
		
		return mav;
	}
}
