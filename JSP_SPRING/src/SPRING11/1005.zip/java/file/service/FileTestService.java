package file.service;

import file.dto.FileTest;

public interface FileTestService {

	public void insertFile(FileTest test);
	
	public FileTest getFile(FileTest file);
}
