package board.service;

import java.util.List;

import board.dto.Board;
import board.util.Paging;

public interface BoardService {

	// 게시글 리스트 조회
	public List getList();

	// 총 게시글 수
	public int getTotal();
	public int getTotalSearch(String search);
	
	// 페이징 리스트 조회
	public List getPagingList(Paging paging);
	public List getPagingListSearch(Paging paging);
	
	// 게시글 입력
	public void write(Board board);
	
	// 게시글 상세 조회
	public Board view(Board board);
	
	// 게시글 수정
	public void update(Board board);

	// 게시글 삭제
	public void delete(Board board);
	
	/*
	 * 게시글 추천상태 확인
	 * 	true - 추천한 게시글
	 * 	false - 추천한적 없는 게시글
	 */
	public boolean recommendCheck(Board chk);
	
	// 추천 로직
	public boolean recommend(Board board);
	
	// 추천수 구하기
	public int getRecommend(Board board);
	
}











