package board.service;

import java.util.List;

import board.dao.BoardDao;
import board.dao.BoardDaoImpl;
import board.dao.RecommendDao;
import board.dao.RecommendDaoImpl;
import board.dto.Board;
import board.util.Paging;

public class BoardServiceImpl implements BoardService {

	private BoardDao boardDao = new BoardDaoImpl();
	private RecommendDao recommendDao = new RecommendDaoImpl();
	
	@Override
	public List getList() {
		return boardDao.selectAll();
	}

	@Override
	public int getTotal() {
		return boardDao.selectCntAll();
	}

	@Override
	public int getTotalSearch(String search) {
		return boardDao.selectCntAllSearch(search);
	}

	@Override
	public List getPagingList(Paging paging) {
		return boardDao.selectPagingList(paging);
	}

	@Override
	public List getPagingListSearch(Paging paging) {
		return boardDao.selectPagingListSearch(paging);
	}

	@Override
	public void write(Board board) {
		boardDao.insert(board);
	}

	@Override
	public Board view(Board board) {
		boardDao.updateHit(board);
		return boardDao.selectBoardByBoardno(board);
	}

	@Override
	public void update(Board board) {
		boardDao.update(board);
	}

	@Override
	public void delete(Board board) {
		boardDao.delete(board);
	}

	@Override
	public boolean recommendCheck(Board board) {
		System.out.println(board);
		if( recommendDao.selectCountRecommend(board) > 0 ) {
			return true;
		} else {
			return false;
		}
	}
	
	@Override	
	public boolean recommend(Board board) {
		if( recommendCheck(board) ) {
			recommendDao.deleteRecommend(board);
			return false;
		} else {
			recommendDao.insertRecommend(board);
			return true;
		}
		
	}
	
	@Override
	public int getRecommend(Board board) {
		return recommendDao.selectTotalRecommend(board);
	}

}













