package board.service;

import board.dto.User;

public interface MemberService {
	
	// 회원가입
	public void join(User user);

	// 로그인
	public boolean login(User user);

	// 닉네임 찾기
	public String getNick(User user);
	
}
