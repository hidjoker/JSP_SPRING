package board.dto;

import java.util.Date;

public class BoardFile {
	private int boardNo;
	private int fileNo;
	private String originName;
	private String storedName;
	private int fileSize;
	private Date uploadDate;
	
	
	@Override
	public String toString() {
		return "File [boardNo=" + boardNo + ", fileNo=" + fileNo + ", originName=" + originName + ", storedName="
				+ storedName + ", fileSize=" + fileSize + ", uploadDate=" + uploadDate + "]";
	}
	public int getBoardNo() {
		return boardNo;
	}
	public void setBoardNo(int boardNo) {
		this.boardNo = boardNo;
	}
	public int getFileNo() {
		return fileNo;
	}
	public void setFileNo(int fileNo) {
		this.fileNo = fileNo;
	}
	public String getOriginName() {
		return originName;
	}
	public void setOriginName(String originName) {
		this.originName = originName;
	}
	public String getStoredName() {
		return storedName;
	}
	public void setStoredName(String storedName) {
		this.storedName = storedName;
	}
	public int getFileSize() {
		return fileSize;
	}
	public void setFileSize(int fileSize) {
		this.fileSize = fileSize;
	}
	public Date getUploadDate() {
		return uploadDate;
	}
	public void setUploadDate(Date uploadDate) {
		this.uploadDate = uploadDate;
	}
}
