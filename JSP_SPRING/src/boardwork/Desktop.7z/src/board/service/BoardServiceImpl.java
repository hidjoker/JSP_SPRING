package board.service;

import java.util.List;

import javax.servlet.http.HttpServletResponseWrapper;

import board.dao.BoardDao;
import board.dao.BoardDaoImpl;
import board.dto.Board;
import board.dto.BoardFile;
import board.dto.Comment;
import board.util.Paging;

public class BoardServiceImpl implements BoardService {

	private BoardDao boardDao = new BoardDaoImpl();
	
	@Override
	public List getList() {
		return boardDao.selectAll();
	}

	@Override
	public int getTotal(Paging paging) {
		return boardDao.selectCntAll(paging);
	}

	@Override
	public List getPagingList(Paging paging) {
		return boardDao.selectPagingList(paging);
	}
	

	@Override
	public void addBoard(Board board) {
		boardDao.insertBoard(board);				
	}

	@Override
	public Board viewBoard(Board board) {
		
		boardDao.addHit(board);
		return boardDao.viewBoard(board);
	}

	@Override
	public void updateBoard(Board board) {
		boardDao.updateBoard(board);
	}

	@Override
	public void delete(Board board) {
		boardDao.deleteBoard(board);
		
	}

	@Override
	public boolean recommend(Board board) {
		boolean res = boardDao.selectRecommend(board);
		if(res) {						
			boardDao.deleteRecommend(board);	
			System.out.println("delete작동");
		} else {			
			boardDao.insertRecommend(board);
		}		
		return res;
	}

	@Override
	public List<Comment> commentList(Board board) {			
		return boardDao.selectCommentByBoardNo(board); 
	}

	@Override
	public void commentInsert(Comment comment) {
		boardDao.insertComment(comment);
		
	}

	@Override
	public void commentDelete(Comment comment) {
		boardDao.deleteComment(comment);
	}

	@Override
	public void insertFile(BoardFile file) {
		boardDao.insertBoardFile(file);
	}

	@Override
	public BoardFile selectFile(Board board) {
		
		return boardDao.selectFileByBoardNo(board);
	}

	@Override
	public void recommendsAllDelete(Board board) {
		boardDao.recommendsAllDelete(board);
	}

	@Override
	public void commentsAllDelete(Board board) {
		boardDao.commentsAllDelete(board);
		
	}

	@Override
	public void deleteFile(Board board) {
		boardDao.deleteFile(board);
	}


	
}













