package board.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import board.dto.Board;
import board.service.BoardServiceImpl;


@WebServlet("/board/recommend.do")
public class BoardRecommendController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("UTF-8");
		response.setContentType("text/html;charset=utf-8");
		
		System.out.println("doget 호출 성공");
		HttpSession session = request.getSession();
		int boardno = Integer.parseInt(request.getParameter("boardno"));
		String id = String.valueOf(session.getAttribute("logid"));
		
		Board board = new Board();
		board.setBoardno(boardno);
		board.setWriterid(id);
		
		BoardServiceImpl service = new BoardServiceImpl();
		boolean res = service.recommend(board);
		PrintWriter out = response.getWriter();
		System.out.println(res);
		
		if(res) {
			out.append("추천");
		}else {
			out.append("비추천");			
		}
		
		
	}



}
