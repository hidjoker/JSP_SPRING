package board.controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import board.dto.Board;
import board.service.BoardServiceImpl;


@WebServlet("/board/delete.do")
public class BoardDeleteController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		int boardno = Integer.parseInt(request.getParameter("boardno"));
		Board board = new Board();
		board.setBoardno(boardno);
		
		//게시글 삭제
		BoardServiceImpl service = new BoardServiceImpl();
		service.delete(board);
		
		//게시글 추천 삭제
		service.recommendsAllDelete(board);
		
		//게시글 코멘트 삭제
		service.commentsAllDelete(board);
		
		//게시글 첨부파일 삭제
		service.deleteFile(board);
		
		
		response.sendRedirect("/board/pagingList.do");
	}
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
	}

}
