package board.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.google.gson.Gson;

import board.dto.Board;
import board.service.BoardServiceImpl;

@WebServlet("/board/listDelete.do")
public class BoardListDeleteController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		System.out.println("doPost 작동");
		request.setCharacterEncoding("UTF-8");
		response.setContentType("text/html;charset=utf-8");
		
		String jsonList = request.getParameter("list");
		Gson gson = new Gson();
		List list = gson.fromJson(jsonList,List.class);
		
		BoardServiceImpl service = new BoardServiceImpl();
		for (Object boardno : list) {
			int num = Integer.parseInt(String.valueOf(boardno));
			System.out.println("num : "+num);
			Board board = new Board();
			board.setBoardno(num);
			service.delete(board);			
		}
		
		response.sendRedirect("/board/pagingList.do");
		
	}

}
