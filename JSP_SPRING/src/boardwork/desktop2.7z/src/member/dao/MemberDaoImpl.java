package member.dao;


import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import DBUtil.DBConn;
import member.dto.User;

public class MemberDaoImpl implements MemberDao{

	Connection conn = DBConn.getConnection();
	PreparedStatement ps = null;
	ResultSet rs = null;
	
	
	@Override
	public void insertMember(User user) {
		
		String sql="INSERT INTO writer values(?,?,?)";
		int res = 0;
		try {
			ps=conn.prepareStatement(sql);
			ps.setString(1, user.getUserId());
			ps.setString(2, user.getUserPw());
			ps.setString(3, user.getUserNick());
			res = ps.executeUpdate();
			
		} catch (SQLException e) {
			e.printStackTrace();
		}finally {
				try {
					if(ps!=null) ps.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
		}
		
		if(res>0) System.out.println("멤버 생성 성공!");
						
	}


	@Override
	public User selectUser(User logUser) {
		String sql="SELECT * FROM writer WHERE userid=?";
		User selectUser = new User();

		try {
			ps=conn.prepareStatement(sql);
			ps.setString(1, logUser.getUserId());
			rs = ps.executeQuery();
			rs.next();
			selectUser.setUserId(rs.getString(1));
			selectUser.setUserPw(rs.getString(2));
			selectUser.setUserNick(rs.getString(3));
			
		} catch (SQLException e) {
			e.printStackTrace();
		}finally {
				try {
					if(rs!=null)rs.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
		}
		
		return selectUser;
		
	}

}
