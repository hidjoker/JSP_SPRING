package member.service;

import member.dto.User;

public interface MemberService {

	public void insertMember(User user);
	
	public User selectUser(User logUser);
}
