package board.controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import board.dao.BoardDaoImpl;
import board.dto.Board;
import board.service.BoardServiceImpl;


@WebServlet("/board/view.do")
public class BoardViewController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		int boardno = Integer.parseInt(request.getParameter("boardno"));
		HttpSession session = request.getSession();
		String id = (String)session.getAttribute("logid");
		
		BoardServiceImpl service = new BoardServiceImpl();
		
		System.out.println(id);
		// boardno를 담은 객체
		Board board1 = new Board();
		board1.setBoardno(boardno);
		board1.setWriterid(id);
		
		// 추천 조회
		BoardDaoImpl dao = new BoardDaoImpl();
		boolean res = dao.selectRecommend(board1);
		
		// 보드 조회
		Board board = service.viewBoard(board1);
		
		request.setAttribute("board", board);
		System.out.println("chkRecommend : "+res);
		request.setAttribute("chkRecommend", res);
		
		request.getRequestDispatcher("/board/view.jsp")
			.forward(request, response);
				
	}


	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

	}

}
