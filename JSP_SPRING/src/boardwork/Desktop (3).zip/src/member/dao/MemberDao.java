package member.dao;

import member.dto.User;

public interface MemberDao {
	
	public void insertMember(User user);
	
	public User selectUser(User logUser);
	
}
