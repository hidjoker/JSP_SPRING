package board.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import DBUtil.DBConn;
import board.dto.Board;
import board.dto.BoardFile;
import board.dto.Comment;
import board.util.Paging;

public class BoardDaoImpl implements BoardDao {

	// DB 연결 객체
	private Connection conn = DBConn.getConnection();
	
	// JDBC 객체
	private PreparedStatement ps;
	private ResultSet rs;
	
	@Override
	public List selectAll() {
		
		// 전체조회 쿼리
		String sql =
				"SELECT" + 
				"    boardno," + 
				"    title," + 
				"    writerid," + 
				"    writer," + 
				"    content," + 
				"    hit," + 
				"    recommend," + 
				"    writtendate" + 
				" FROM board" + 
				" ORDER BY boardno";
		
		// 결과 List
		List boardList = new ArrayList();
		try {
			// PreparedStatement 생성
			ps = conn.prepareStatement(sql);
			
			// ResultSet 반환
			rs = ps.executeQuery();
			
			while( rs.next() ) {
				Board board = new Board();
				
				board.setBoardno( rs.getInt("boardno") );
				board.setTitle( rs.getString("title") );
				board.setWriterid( rs.getString("writerid") );
				board.setWriter( rs.getString("writer") );
				board.setContent( rs.getString("content") );
				board.setHit( rs.getInt("hit") );
				board.setRecommend( rs.getInt("recommend") );
				board.setWrittendate( rs.getDate("writtendate") );
				
				boardList.add(board);
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				if(rs!=null)	rs.close();
				if(ps!=null)	ps.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			
		}
		
		return boardList;
	}

	@Override
	public int selectCntAll(Paging paging) {
		String sql = "SELECT count(*) FROM board Where title Like ?";	
		String search = paging.getSearch();
		if( !"".equals(search) && search != null ) {
			 search="%"+search +"%";
		}else {
			search="%%";
		}
		
		System.out.println(search);
		int cnt = 0;
		try {
			System.out.println("트라이문 진입");
			ps = conn.prepareStatement(sql);
			ps.setString(1, search);
			rs = ps.executeQuery();
			rs.next();
			cnt = rs.getInt(1);
			
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				if(rs!=null) rs.close();
				if(ps!=null) ps.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		System.out.println("cnt : "+cnt);
		return cnt;
	}

	@Override
	public List selectPagingList(Paging paging) {
		
		String sql
			= "SELECT * FROM (" + 
			"    SELECT rownum rnum, B.* FROM (" + 
			"        SELECT * FROM board" + 
			"        WHERE title LIKE ?" +
			"        ORDER BY boardno DESC" + 
			"    ) B" + 
			"    ORDER BY rnum" + 
			" )" + 
			" WHERE rnum BETWEEN ? AND ?";
		
		String search = paging.getSearch();
		if( !"".equals(search) && search != null ) {
			 search="%"+search +"%";
		}else {
			search="%%";
		}
		
		
		ArrayList<Board> boardList = new ArrayList<>();
		try {
			ps = conn.prepareStatement(sql);
			
			ps.setString(1, search);
			ps.setInt(2, paging.getStartNo() );
			ps.setInt(3, paging.getEndNo() );

			// ResultSet 반환
			rs = ps.executeQuery();
			
			while( rs.next() ) {
				Board board = new Board();
				
				board.setBoardno( rs.getInt("boardno") );
				board.setTitle( rs.getString("title") );
				board.setWriterid( rs.getString("writerid") );
				board.setWriter( rs.getString("writer") );
				board.setContent( rs.getString("content") );
				board.setHit( rs.getInt("hit") );
				board.setRecommend( rs.getInt("recommend") );
				board.setWrittendate( rs.getDate("writtendate") );
				
				boardList.add(board);
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				if(rs!=null)	rs.close();
				if(ps!=null)	ps.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			
		}
		
		return boardList;
	}
	
	

	@Override
	public void insertBoard(Board board) {
		
		String sql = "INSERT INTO BOARD(boardno,title,writer,content,hit,recommend)"
				+ "VALUES(?,?,?,?,?,?)";
		int check = 0;
		try {
			System.out.println("트라이문 진입!");
			ps = conn.prepareStatement(sql);
			ps.setInt(1, board.getBoardno());
			ps.setString(2, board.getTitle());
			ps.setString(3, board.getWriter());
			ps.setString(4, board.getContent());
			ps.setInt(5, board.getHit());
			ps.setInt(6, board.getRecommend());
			
			ps.executeQuery();
						
		} catch (SQLException e) {
			e.printStackTrace();
		}finally {
			try {
				ps.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}

	}

	@Override
	public Board viewBoard(Board board1) {
		
		int boardno = board1.getBoardno();
		String sql = "SELECT * FROM BOARD WHERE boardno = ?";
		
		Board board = new Board();
		
		try {
			ps = conn.prepareStatement(sql);
			ps.setInt(1, boardno);
			rs = ps.executeQuery();
			
			rs.next();
						
			board.setBoardno( rs.getInt("boardno") );
			board.setTitle( rs.getString("title") );
			board.setWriterid( rs.getString("writerid") );
			board.setWriter( rs.getString("writer") );
			board.setContent( rs.getString("content") );
			board.setHit( rs.getInt("hit") );
			board.setRecommend( rs.getInt("recommend") );
			board.setWrittendate( rs.getDate("writtendate") );
			
		} catch (SQLException e) {
			e.printStackTrace();
		}finally {
			try {
				if(rs!=null) rs.close();
				if(ps!=null) ps.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		
		return board;
	}

	@Override
	public void updateBoard(Board board) {
		
		
		String sql="UPDATE board SET title=?, content=?, writtendate=sysdate WHERE boardno=? ";
		int check=0;
		
		try {
			System.out.println("트라이문 진입");
			ps = conn.prepareStatement(sql);
			ps.setString(1, board.getTitle());
			ps.setString(2, board.getContent());
			ps.setInt(3, board.getBoardno());
			check = ps.executeUpdate();

		} catch (SQLException e) {
			e.printStackTrace();
		}finally {
				try {
					if(ps!=null)ps.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
		}
		
		if(check>0)System.out.println("수정 성공!!");
		if(check==0)System.out.println("수정 실패!!");
		
	}

	@Override
	public void deleteBoard(Board board) {
		int boardno = board.getBoardno();
		String sql = "DELETE FROM board WHERE boardno=?";
		int res = 0;
		try {
			ps = conn.prepareStatement(sql);
			ps.setInt(1, boardno);
			res = ps.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		}finally {
				try {
					if(ps!=null) ps.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
		}
		
		if(res>0)System.out.println("삭제완료");
		
		
	}

	@Override
	public void addHit(Board board) {
		
		int boardno = board.getBoardno();
		String sql ="UPDATE board SET hit=hit+1 WHERE boardno=?"; 
		int res = 0;
		
		try {
			ps = conn.prepareStatement(sql);
			ps.setInt(1, boardno);
			res = ps.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		}finally {
				try {
					if(ps!=null)ps.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
		}
		
		if(res>0)System.out.println("조회수 추가 성공");
		
	}

	@Override
	public boolean selectRecommend(Board board) {
		int boardno = board.getBoardno();
		String id = board.getWriterid();		
		String sql="SELECT count(*) FROM recommend WHERE userid=? AND boardno=?";
		try {
			ps = conn.prepareStatement(sql);
			ps.setString(1, id);
			ps.setInt(2, boardno);
			rs = ps.executeQuery();
			rs.next();
			if(rs.getInt(1)>0) return true;
			
		} catch (SQLException e) {
			e.printStackTrace();
		}finally {
				try {
					if(rs!=null) rs.close();
					if(ps!=null) ps.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
		}	
		return false;
	}
	
	
	@Override
	public void insertRecommend(Board board) {
		String id = board.getWriterid();
		int boardno = board.getBoardno();
		
		String sql1 = "INSERT INTO recommend values(?,?)";
		String sql2 = "UPDATE board SET recommend=recommend+1 WHERE boardno=?";
		
		try {
			ps = conn.prepareStatement(sql1);
			ps.setString(1, id);
			ps.setInt(2, boardno);
			ps.executeUpdate();
			
		} catch (SQLException e) {
			e.printStackTrace();
		}finally {
				try {
					if(ps!=null) ps.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
		}
		
		try {
			ps = conn.prepareStatement(sql2);
			ps.setInt(1, boardno);
			ps.executeUpdate();
			
		} catch (SQLException e) {
			e.printStackTrace();
		}finally {
			try {
				if(ps!=null) ps.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}		
		
	}

	@Override
	public void deleteRecommend(Board board) {
		
		String id = board.getWriterid();
		int boardno = board.getBoardno();
		
		String sql1 = "DELETE FROM recommend WHERE userid=? AND boardno=?";
		String sql2 = "UPDATE board SET recommend=recommend-1 WHERE boardno=?";
		
		try {
			ps = conn.prepareStatement(sql1);
			ps.setString(1, id);
			ps.setInt(2, boardno);
			int res = ps.executeUpdate();
			System.out.println(res);
		} catch (SQLException e) {
			e.printStackTrace();
		}finally {
				try {
					if(ps!=null) ps.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
		}
		
		try {
			ps = conn.prepareStatement(sql2);
			ps.setInt(1, boardno);
			ps.executeUpdate();
			
		} catch (SQLException e) {
			e.printStackTrace();
		}finally {
			try {
				if(ps!=null) ps.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}		
		
	}

	@Override
	public List<Comment> selectCommentByBoardNo(Board board) {
		int boardno = board.getBoardno();
		String sql = "SELECT * FROM COMMENTTB WHERE boardno=? ORDER BY commentno";
		ArrayList<Comment> list = new ArrayList<>();
		
		try {
			ps = conn.prepareStatement(sql);
			ps.setInt(1, boardno);
			rs = ps.executeQuery();	
			
			while(rs.next()) {
				Comment comment = new Comment();
				comment.setCommentNo(rs.getInt(1));
				comment.setBoardNo(rs.getInt(2));
				comment.setUserId(rs.getString(3));
				comment.setCommentWriter(rs.getString(4));
				comment.setPw(rs.getString(5));
				comment.setContent(rs.getString(6));
				comment.setWrittenDate(rs.getDate(7));
				
				list.add(comment);
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
		}finally {
			try {
					if(rs!=null) rs.close();
					if(ps!=null) ps.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
		}		
		return list;
	}

	@Override
	public void insertComment(Comment comment) {
		
		String sql = "INSERT INTO commentTB "
				+ "VALUES(commentTB_seq.nextVal,?,?,?,null,?,sysdate)";
		
		try {
			ps = conn.prepareStatement(sql);
			ps.setInt(1, comment.getBoardNo());
			ps.setString(2, comment.getUserId());
			ps.setString(3, comment.getCommentWriter());
			ps.setString(4, comment.getContent());
			int res = ps.executeUpdate();
			System.out.println(res);
			
		} catch (SQLException e) {
			e.printStackTrace();
		}finally {
				try {
					if(ps!=null) ps.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
		}
				
	}

	@Override
	public void deleteComment(Comment comment) {

		String sql = "DELETE FROM commentTB WHERE boardno=? AND commentno=?";
		
		try {
			ps = conn.prepareStatement(sql);
			ps.setInt(1, comment.getBoardNo());
			ps.setInt(2, comment.getCommentNo());
			
			int res = ps.executeUpdate();
			
			if(res>0) System.out.println("삭제 성공");
			
		} catch (SQLException e) {
			e.printStackTrace();
		}finally {
			try {
				if(ps!=null) ps.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
		}
	}

	@Override
	public void insertBoardFile(BoardFile file) {
		
		String sql = "INSERT INTO board_file values(?,seq_board_file.nextval,?,?,?,sysdate)";
		
		try {
			ps = conn.prepareStatement(sql);
			ps.setInt(1, file.getBoardNo());
			ps.setString(2, file.getOriginName());
			ps.setString(3, file.getStoredName());
			ps.setInt(4, file.getFileSize());
			int res = ps.executeUpdate();
			if(res>0) System.out.println("파일 DB 업 완료"); 
			
		} catch (SQLException e) {
			e.printStackTrace();
		}finally {
				try {
					if(ps!=null) ps.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
		}
		
	}


}











