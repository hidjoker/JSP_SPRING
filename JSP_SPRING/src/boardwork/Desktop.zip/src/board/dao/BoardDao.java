package board.dao;

import java.util.List;

import board.dto.Board;
import board.dto.Comment;
import board.util.Paging;

public interface BoardDao {
	
	// board 테이블 전체 조회
	public List selectAll();
	
	
	// 총 게시글 수 조회
	public int selectCntAll(Paging paging);
	
	// 페이징 리스트 조회
	public List selectPagingList(Paging paging);
	
	// 게시글 작성
	public void insertBoard(Board board);
	
	// 조회수 추가
	public void addHit(Board board);
	
	// 게시글 확인
	public Board viewBoard(Board board);
	
	// 게시글 수정
	public void updateBoard(Board board);
	
	// 게시글 삭제
	public void deleteBoard(Board board);
	
	// 추천수 조회
	public boolean selectRecommend(Board board);
	
	// 추천수 추가
	public void insertRecommend(Board board);
	
	// 추천수 삭제
	public void deleteRecommend(Board board);
	
	// 댓글 조회
	public List<Comment> selectCommentByBoardNo(Board board);
	
	
}















