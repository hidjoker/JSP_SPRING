package member.service;

import member.dao.MemberDaoImpl;
import member.dto.User;

public class MemberServiceImpl implements MemberService{

	MemberDaoImpl dao = new MemberDaoImpl();
	
	@Override
	public void insertMember(User user) {
		dao.insertMember(user);	
	}

	@Override
	public User selectUser(User logUser) {
		return dao.selectUser(logUser);
	}

}
