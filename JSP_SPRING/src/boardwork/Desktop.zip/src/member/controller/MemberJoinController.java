package member.controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import member.dto.User;
import member.service.MemberService;
import member.service.MemberServiceImpl;


@WebServlet("/member/join.do")
public class MemberJoinController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
 
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.getRequestDispatcher("/member/joinForm.jsp")
			.forward(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("UTF-8");
		response.setContentType("text/html;charset=utf-8");
		
		User user = new User();
		user.setUserId(request.getParameter("id"));
		user.setUserPw(request.getParameter("pw"));
		user.setUserNick(request.getParameter("nick"));
		
		MemberServiceImpl service = new MemberServiceImpl();
		service.insertMember(user);
		
		response.sendRedirect("/member/login.do");
	
	}

}
