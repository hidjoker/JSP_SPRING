package member.controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import member.dto.User;
import member.service.MemberService;
import member.service.MemberServiceImpl;

@WebServlet("/member/login.do")
public class MemberLoginController extends HttpServlet {
	private static final long serialVersionUID = 1L;
 	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.getRequestDispatcher("/member/loginForm.jsp")
			.forward(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("UTF-8");
		response.setContentType("text/html;charset=utf-8");
		
		
		String logId = request.getParameter("id");
		String logPw = request.getParameter("pw");
		
		User logUser = new User();
		logUser.setUserId(logId);
		
		MemberServiceImpl service = new MemberServiceImpl();
		User selectUser = service.selectUser(logUser);
		
		HttpSession session = request.getSession();
		
		if(logId.equals(selectUser.getUserId())
				&&logPw.equals(selectUser.getUserPw())) {			
			session.setAttribute("login", true);
			session.setAttribute("logid", selectUser.getUserId());
			session.setAttribute("lognick", selectUser.getUserNick());
			
		}else {
			session.setAttribute("login", false);
		}
		
		request.getRequestDispatcher("/member/logProc.jsp")
				.forward(request, response);			
		
	}

}
