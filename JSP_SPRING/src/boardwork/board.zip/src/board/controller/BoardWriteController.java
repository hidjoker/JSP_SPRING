package board.controller;

import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Iterator;
import java.util.List;
import java.util.UUID;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.FileUploadException;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;

import board.dto.Board;
import board.dto.BoardFile;
import board.service.BoardServiceImpl;
import board.util.Paging;


@WebServlet("/board/write.do")
public class BoardWriteController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		HttpSession session =  request.getSession();
		
		request.getRequestDispatcher("/board/write.jsp")
			.forward(request, response);
						
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {	
		
		//전송 파라미터 한글 인코딩 설정 : UTF-8
		request.setCharacterEncoding("UTF-8");		
		//응답 객체 MIME설정 : HTML, 한글인코딩 UTF-8
		response.setContentType("text/html;charset=UTF-8");		
		//응답 객체 출력 스트림
		PrintWriter out = response.getWriter();
		
		
		boolean isMultipart =ServletFileUpload.isMultipartContent(request);
		
		if(isMultipart) {

			System.out.println("파일전송 기반");
			//			// 디스크 기반의 파일아이템 처리 API - DiskFileItemFactory
			DiskFileItemFactory factory = null;
			factory = new DiskFileItemFactory();
			
			// 3. 업로드 아이템이 적당히 작으면 메모리에서 처리
			int maxMem = 1 * 1024 * 1024; //1MB
			factory.setSizeThreshold(maxMem); //메모리처리사이즈 설정
			
			System.out.println(getServletContext().getRealPath("tmp"));

			// 4. 적당히 큰 아이템이면 임시파일을 만들어서 처리(디스크)
			factory.setRepository(new File(getServletContext().getRealPath("tmp")));
			
			// 5. 업로드 허용기준에 맞는 용량의 파일이면 업로드 수행
			long maxFile = 10 * 1024 * 1024 ; //10MB
			ServletFileUpload upload = new ServletFileUpload(factory);
			upload.setSizeMax(maxFile); //업로드 용량 제한 설정
			
			// 6. 업로드 데이터 파싱(추출) - 임시파일 업로드
			List<FileItem> items = null;
			
			try {
				//요청객체 request에서 전달 데이터 추출하기
				items = upload.parseRequest(request);
			} catch (FileUploadException e) {
				e.printStackTrace();
			}

			// Board DTO 객체 만들기
			BoardServiceImpl service =  new BoardServiceImpl();
			Board board = new Board();
			int boardNo = service.getTotal(new Paging(0))+1;
			String writer = (String)request.getSession().getAttribute("lognick");
			String id = (String)request.getSession().getAttribute("logid");
			board.setBoardno(boardNo);
			board.setWriter(writer);
			board.setWriterid(id);
			board.setHit(0);
			board.setRecommend(0);
			
			int fileSize = 0;
			
			// 7. 폼필드 처리
			Iterator<FileItem> iter = items.iterator();

			
			while(iter.hasNext()) {
				FileItem item = iter.next();
				
				// 빈파일(비정상파일)이 업로드 되었을 때 처리 안함
				if(item.getSize() <= 0) continue;
				
				if(item.isFormField()) {
					// form-data 일 경우
					// 키=값 쌍으로 전달된 데이터일 경우
					
					System.out.println("폼 필드 : "+item.getFieldName()
					+", 값 : "+item.getString());

					if( item.getFieldName().equals("title")) {				
						board.setTitle(new String
								(item.getString().getBytes("8859_1"),"utf-8"));

					}
					if( item.getFieldName().equals("content")) {				
						board.setContent(new String
								(item.getString().getBytes("8859_1"),"utf-8"));
					}
				
				}else {
					
					// java.util.UUID
					UUID uid = UUID.randomUUID();
					String u = uid.toString().split("-")[0];
					System.out.println(u);
					
					
					// 필요한 추가 처리
					// 데이터베이스에 업로드한 파일의 정보를 기록해둔다
					//
					// 업로드파일 PK
					// 원본 파일명
					// 저장 파열명(UUID가 적용된 파일명)
					// 업로드한 사람(userId)
					// 업로드한 시간(생략 가능)
					// 게시글 번호(첨부파일일 경우)
					
					fileSize = (int) item.getSize();
					String originName = item.getName();
					// 파일 데이터일 경우
					File up = new File(
							getServletContext().getRealPath("upload"),item.getName()+"_"+u);
					
					String storedName = up.getName();
			
					
					BoardFile file = new BoardFile();
					file.setBoardNo(boardNo);
					file.setFileSize(fileSize);
					file.setOriginName(originName);
					file.setStoredName(storedName);
					
					service.insertFile(file);					
					// System.out.println(up);
					// System.out.println(up.exists());
					
					
					try {
						// realPath에 지정한 파일로 기록하기(실제 업로드)
						item.write(up);
						item.delete(); //임시파일 삭제하기
					} catch (Exception e) {
						e.printStackTrace();
					}
					
			     }	
			}

			
			System.out.println("boardno : "+board.getBoardno());
			System.out.println("content : "+board.getContent());
			System.out.println("hit : "+board.getHit());
			System.out.println("recommend : "+board.getRecommend());
			System.out.println("writer : "+board.getWriter());
			System.out.println("writerid : "+board.getWriterid());
			System.out.println("title : "+board.getTitle());

			service.addBoard(board);
			
			response.sendRedirect("/board/pagingList.do");
			
			
		}else {
			System.out.println("미파일 전송");
			response.sendRedirect("/board/pagingList.do");

		}
		
	}

}
