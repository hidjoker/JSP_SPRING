package board.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.google.gson.Gson;

import board.dao.BoardDaoImpl;
import board.dto.Board;
import board.dto.BoardFile;
import board.dto.Comment;
import board.service.BoardServiceImpl;


@WebServlet("/board/view.do")
public class BoardViewController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		request.setCharacterEncoding("UTF-8");
		response.setContentType("text/html;charset=utf-8");
		
		int boardno = Integer.parseInt(request.getParameter("boardno"));
		HttpSession session = request.getSession();
		String id = (String)session.getAttribute("logid");
		
		BoardServiceImpl service = new BoardServiceImpl();
		
		// boardno를 담은 객체
		Board board1 = new Board();
		board1.setBoardno(boardno);
		board1.setWriterid(id);
		
		// 추천 조회
		BoardDaoImpl dao = new BoardDaoImpl();
		boolean res = dao.selectRecommend(board1);
		
		// 보드 조회
		Board board = service.viewBoard(board1);
		
		// 코멘트 조회
		List<Comment> list = new ArrayList<>();
		list = service.commentList(board1);
		
		// 첨부파일 조회
		BoardFile file = service.selectFile(board1);
		
		request.setAttribute("board", board);
		request.setAttribute("chkRecommend", res);
		request.setAttribute("comment", list);
		request.setAttribute("file", file);
		System.out.println(list.size());
		
		request.getRequestDispatcher("/board/view.jsp")
			.forward(request, response);
				
	}


	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		request.setCharacterEncoding("UTF-8");
		response.setContentType("text/html;charset=utf-8");
		
		int boardno = Integer.parseInt(request.getParameter("boardno"));
		String commentWriter = request.getParameter("commentwriter");
		String commentId = request.getParameter("commentid");
		String content = request.getParameter("content");
		String sort = request.getParameter("sort");
		
		System.out.println("boardno : "+boardno);
		System.out.println("commentId : "+commentId);
		System.out.println("content : "+content);
		System.out.println("commentWriter : "+commentWriter);
		System.out.println("sort : "+sort);
			
		Comment comment = new Comment();
		comment.setBoardNo(boardno);
		comment.setCommentWriter(commentWriter);
		comment.setUserId(commentId);
		comment.setContent(content);
		
		BoardServiceImpl service = new BoardServiceImpl();

		if(sort.equals("add")) {		
		service.commentInsert(comment);
		}else if(sort.equals("del")) {
			int commentNo = Integer.parseInt(request.getParameter("commentno"));
			System.out.println("commentNo : " + commentNo);
			comment.setCommentNo(commentNo);
			service.commentDelete(comment);
		}
		
		// boardno를 담은 객체
		Board board1 = new Board();
		board1.setBoardno(boardno);
		board1.setWriterid(commentId);
		
		// 코멘트 조회
		List<Comment> list = new ArrayList<>();
		list = service.commentList(board1);
		
		Gson gson = new Gson();
		String gsonList = gson.toJson(list);
		
		PrintWriter out = response.getWriter();
		out.append(gsonList);	
		
		
	}

}
