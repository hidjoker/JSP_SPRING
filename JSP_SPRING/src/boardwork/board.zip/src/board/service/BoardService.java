package board.service;

import java.util.List;

import board.dto.Board;
import board.dto.BoardFile;
import board.dto.Comment;
import board.util.Paging;

public interface BoardService {

	// 게시글 리스트 조회
	public List getList();

	// 총 게시글 수
	public int getTotal(Paging paging);
	
	// 페이징 리스트 조회
	public List getPagingList(Paging paging);
	
	// 게시글 작성
	public void addBoard(Board board);
	
	// 게시글 확인
	public Board viewBoard(Board board);

	// 게시글 수정
	public void updateBoard(Board board);
	
	// 게시글 삭제
	public void delete(Board board);
	
	// 추천수
	public boolean recommend(Board board);
	
	// 댓글 조회
	public List<Comment> commentList(Board board);
	
	// 댓글 추가
	public void commentInsert(Comment comment);
	
	// 댓글 삭제
	public void commentDelete(Comment comment);
	
	// 파일 추가
	public void insertFile(BoardFile file);
	
	// 첨부파일 조회
	public BoardFile selectFile(Board board);
	
	// 추천 삭제
	public void recommendsAllDelete(Board board);
	
	// 댓글 전부 삭제
	public void commentsAllDelete(Board board);
	
	// 첨부파일 삭제
	public void deleteFile(Board board);
	
}











