package web.interceptor;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.handler.HandlerInterceptorAdapter;

import web.dto.Board;
import web.service.BoardService;

public class BoardInterceptor extends HandlerInterceptorAdapter{

	private static Logger logger
		= LoggerFactory.getLogger(BoardInterceptor.class);
	
	@Autowired BoardService service;
	
	@Override
	public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler)
			throws Exception {
		logger.info(" + + + 인터셉터 시작 + + +");
		logger.info("request URI : "+request.getRequestURI());
		
		HttpSession session = request.getSession();
		
		if(session.getAttribute("login")==null) {
			logger.info("로그인 하지 않음 쓰기 비활성화");
			response.sendRedirect("/error/loginErr");
			return false;
		}
		if("/board/update".equals(request.getRequestURI())||
				"/board/delete".equals(request.getRequestURI())) {
			
			Board board = new Board();
			board.setBoardno(Integer.parseInt(request.getParameter("boardno")));
			Board resBoard = service.view(board);			
			if(!resBoard.getId().equals(String.valueOf(session.getAttribute("logid")))) {
				logger.info("작성자와 일치하지 않습니다");
				response.sendRedirect("/error/neIdErr?boardno="+board.getBoardno());
				return false;
			}
		}
		
		return true;
	}
	
	@Override
	public void postHandle(HttpServletRequest request, HttpServletResponse response, Object handler,
			ModelAndView modelAndView) throws Exception {
		logger.info(" + + + 인터셉터 종료 + + +");
		super.postHandle(request, response, handler, modelAndView);
	}
}
