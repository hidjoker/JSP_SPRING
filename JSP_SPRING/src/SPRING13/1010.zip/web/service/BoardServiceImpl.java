package web.service;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import web.controller.BoardController;
import web.dao.BoardDao;
import web.dto.Board;
import web.dto.Comment;
import web.dto.Paging;

@Service
public class BoardServiceImpl implements BoardService{

	private static Logger logger
	= LoggerFactory.getLogger(BoardController.class);

	@Autowired private BoardDao dao;
	
	@Override
	public int totalCnt() {
		int total = dao.totalCnt();
		return total;
	}
	
	@Override
	public List<Board> list(Paging paging) {
		List list = dao.list(paging);
		return list;
	}

	@Override
	public Board view(Board board) {
		dao.hit(board);
		return dao.select(board);
	}

	@Override
	public void write(Board board) {
		dao.write(board);	
	}

	@Override
	public void updateBoard(Board board) {
		dao.updateBoard(board);
	}

	@Override
	public void deleteBoard(Board board) {
		dao.deleteBoard(board);
	}

	@Override
	public List<Comment> commentList(Board board) {
		return dao.selectCommentByBoardNo(board);
	}


	
	
	
}
