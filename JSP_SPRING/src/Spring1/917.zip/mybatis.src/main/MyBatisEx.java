package main;

import org.apache.ibatis.session.SqlSession;

import dao.DeptDao;
import dto.Dept;
import mybatis.MyBatisConnectionFactory;

public class MyBatisEx {
	
	public static void main(String[] args) {
		
		// 오라클 DB 컨넥션 얻기
		SqlSession sqlSession
			= MyBatisConnectionFactory
				.getSqlSessionFactory()
				.openSession();
		
		// sqlSession에 SQL 연결하기
		DeptDao deptDao = sqlSession.getMapper(DeptDao.class);
		
		// SQL 수행하기
		Dept resultDept = deptDao.selectByDeptno(10);
		
		// 결과 출력
		System.out.println(resultDept);
		
	}
	
}
