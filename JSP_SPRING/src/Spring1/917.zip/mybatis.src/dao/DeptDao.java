package dao;

import dto.Dept;

public interface DeptDao {

	public Dept selectByDeptno(int deptno);
	
	
	
}
