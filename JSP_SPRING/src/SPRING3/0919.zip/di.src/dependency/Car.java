package dependency;

public class Car {

	private Tire tire;
	
	public Car() {
		tire = new GoldTire(); //인스턴스가 GoldTire에 의존적
//		tire = new SilverTire(); //인스턴스가 SilverTire에 의존적
	}
	
	public String getTire() {
		return tire.getProduct() + " 장착함!!";
	}
}


