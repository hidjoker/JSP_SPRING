package dependency;

public class Person {

	public static void main(String[] args) {
		
		// Person프로그램이 Car객체에 대한 의존성이 발생한다
		Car car = new Car();
		
		System.out.println(car);
		
		System.out.println(car.getTire());
		
	}
	
}
