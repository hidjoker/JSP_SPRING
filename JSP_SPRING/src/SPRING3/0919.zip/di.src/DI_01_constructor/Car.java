package DI_01_constructor;

import dependency.Tire;

public class Car {
	
	private Tire tire;
		
	// 의존성 주입 지점
	// 인스턴스는 자기가 직접 타이어를 고르지 않고
	// 넘겨받는 Tire객체를 장착하게 된다
	public Car(Tire tire) {
		this.tire = tire;
	}
	
	public String getTire() {
		return tire.getProduct() + " 장착!!";
	}
	
}
