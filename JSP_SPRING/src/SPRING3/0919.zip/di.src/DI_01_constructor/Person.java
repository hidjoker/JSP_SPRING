package DI_01_constructor;

import dependency.GoldTire;

public class Person {
	
	public static void main(String[] args) {
		
		// 의존성 주입시키기(객체 넘겨주기)
		Car car = new Car(new GoldTire());
//		Car car = new Car(new SilverTire());
		
		System.out.println(car.getTire());
		
	}
	
}
