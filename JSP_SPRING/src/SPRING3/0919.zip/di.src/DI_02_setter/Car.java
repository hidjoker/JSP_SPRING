package DI_02_setter;

import dependency.Tire;

public class Car {
	
	private Tire tire;

	public String getTire() {
		return tire.getProduct() +  " 장착함!!!";
	}

	public void setTire(Tire tire) {
		this.tire = tire;
	}
	
	
}
