package DI_02_setter;

import dependency.GoldTire;
import dependency.SilverTire;

public class Person {

	public static void main(String[] args) {
		
		Car car = new Car();
		
		car.setTire(new SilverTire());
//		car.setTire(new GoldTire());
		
		System.out.println(car.getTire());
		
	}
}
