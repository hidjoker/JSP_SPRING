package board.dao;

import board.dto.User;

public interface MemberDao {

	// 회원가입
	public void insert(User user);

	// ID와 PW로 유저 찾기
	public int selectCntByIdAndPw(User user);

	// ID로 닉네임 찾기
	public String selectNickById(User user);
	
}
