package board.controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import board.dto.User;
import board.service.MemberService;
import board.service.MemberServiceImpl;

@WebServlet("/member/join.do")
public class MemberJoinController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	private MemberService memberService = new MemberServiceImpl();
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.getRequestDispatcher("/member/join.jsp")
			.forward(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		User user = new User();
		
		user.setUserid( request.getParameter("userid") );
		user.setUserpw( request.getParameter("userpw") );
		user.setUsernick( request.getParameter("usernick") );
		
		memberService.join(user);
		
		response.sendRedirect("/member/main.do");
	}
}
