package web.controller;


import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import web.dto.Member;
import web.service.MemberService;

@Controller
public class MemberController {

	private static Logger logger
		= LoggerFactory.getLogger(MemberController.class);
	
	@Autowired
	private MemberService service;
	
	
	@RequestMapping(value="/member/main")
	public void main() {
		logger.info("메인메뉴 접속");
	};
	
	
	@RequestMapping(value="/member/join", method=RequestMethod.GET)
	public void joinForm() {};
	
	
	@RequestMapping(value="/member/join", method=RequestMethod.POST)
	public void joinProc(Member member,HttpServletResponse resp) {
			
		resp.setContentType("text/html;charset=utf-8");
		
		int res = service.searchById(member);
		PrintWriter out = null;
		
		try {
			out = resp.getWriter();
		} catch (IOException e) {
			e.printStackTrace();
		}	
		if(res==0) {
			service.join(member);
			out.println("<script>");
			out.println("alert('회원가입 성공!')");
			out.println("location.href='/member/main'");
			out.println("</script>");			
			out.close();
		}else {
			out.println("<script>");
			out.println("alert('fail:이미 존재하는 아이디!')");
			out.println("location.href='/member/join'");
			out.println("</script>");			
			out.close();
		}
		
	};
	
	@RequestMapping(value="/member/login", method=RequestMethod.GET)
	public void loginForm() {
		logger.info("로그인페이지 접속");
	};

	@RequestMapping(value="/member/login", method=RequestMethod.POST)
	public void loginProc(Member member,HttpSession session,HttpServletResponse resp) {
		
		int res = service.search(member);
		
		resp.setContentType("text/html;charset='utf-8'");
		
		PrintWriter out = null;
		
		try {
			out = resp.getWriter();
		} catch (IOException e) {
			e.printStackTrace();
		}
		if(res>0) {
			Member resMem  = service.select(member);
			session.setAttribute("login", true);
			session.setAttribute("logid", resMem.getId());
			session.setAttribute("lognick", resMem.getNick());
			out.println("<script>");
			out.println("alert('로그인 성공')");
			out.println("location.href='/member/main'");
			out.println("</script>");
			out.close();			
		}else {
			out.println("<script>");
			out.println("alert('로그인 실패')");
			out.println("location.href='/member/login'");
			out.println("</script>");
			out.close();
		}				
	};
	
	@RequestMapping(value="/member/logout")
	public String logout(HttpSession session) {
		session.invalidate();
		return "redirect:/member/main"; 			
	};
	
	@RequestMapping(value="/member/info")
	public void info(HttpSession session,Model m) {
		String id = (String)session.getAttribute("logid");
		Member member = new Member();
		member.setId(id);
		Member resMem = service.select(member);
		m.addAttribute("member", resMem);
	};
	
}
