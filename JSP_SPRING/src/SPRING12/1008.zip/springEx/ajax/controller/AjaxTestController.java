package ajax.controller;

import java.io.IOException;
import java.io.Writer;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class AjaxTestController {

	private static final Logger logger
		= LoggerFactory.getLogger(AjaxTestController.class);
	
	@RequestMapping(value="/ajax/ajaxTest",method=RequestMethod.GET)
	public String ajaxTest() {
		return "ajax/ajaxTest";
	}
	
	//json형식으로 입력하는 법
	@RequestMapping(value="/ajax/ajax01",method=RequestMethod.POST)
	public void ajax01(HttpServletResponse resp) {
		
		//한글폰트1
		resp.setContentType("html/text;charset=utf-8");
		Writer writer=null;
		
		try {
			writer = resp.getWriter();
		} catch (IOException e1) {
			e1.printStackTrace();
		}
		logger.info("AJAX 요청 받음");
		
		try {
//			writer.append("HIHIHI");
			writer.append("{\"result1\":\"하이\"}");
		} catch (IOException e) {
			e.printStackTrace();
		}

	}
	
	@RequestMapping(value="/ajax/ajaxTest02",method=RequestMethod.GET)
	public String ajaxTest02() {
		
		return "ajax/ajaxTest02";
	}
	
	//jackson.core 사용법
	@RequestMapping(value="/ajax/ajax02",method=RequestMethod.POST
			//한글폰트(방법2)
			,produces = "application/json;charset=utf-8")
	public @ResponseBody Map<String,String> ajax02() {
		HashMap<String,String> map = new HashMap<>();
		map.put("one", "안녕");
		return map;
	}
	
	@RequestMapping(value="/ajax/ajaxTest03",method=RequestMethod.GET)
	public String ajaxTest03() {
		
		return "ajax/ajaxTest03";
	}
	
	//json-lib 사용법
	@RequestMapping(value="/ajax/ajax03",method=RequestMethod.POST)
	public ModelAndView ajax03(HttpServletResponse resp) {
		//한글폰트 3
		resp.setContentType("application/json;charset=utf-8");
		
		//한글폰트 4
//		String str ="안녕";
//		try {
//			URLEncoder.encode(str, "UTF-8");
//		} catch (UnsupportedEncodingException e) {
//			e.printStackTrace();
//		}
		
		ModelAndView mav = new ModelAndView();
		mav.setViewName("jsonView");
		mav.addObject("result","안녕");
		return mav;
	}
	
}
