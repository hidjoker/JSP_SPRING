package board.dao;

import java.util.List;

public interface BoardDao {
	
	// board 테이블 전체 조회
	public List selectAll();
	
}
