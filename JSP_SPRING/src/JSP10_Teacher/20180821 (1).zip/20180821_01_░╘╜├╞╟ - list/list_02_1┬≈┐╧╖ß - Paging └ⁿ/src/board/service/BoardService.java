package board.service;

import java.util.List;

public interface BoardService {

	// 게시글 리스트 조회
	public List getList();
	
}
