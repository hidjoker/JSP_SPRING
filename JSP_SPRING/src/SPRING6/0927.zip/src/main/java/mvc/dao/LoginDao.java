package mvc.dao;

public interface LoginDao {
	
	

}
