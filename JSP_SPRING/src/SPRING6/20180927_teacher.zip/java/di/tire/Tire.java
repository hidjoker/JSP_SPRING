package di.tire;

public interface Tire {

	//타이어 제품 종류 반환
	public String getProduct();
	
}
