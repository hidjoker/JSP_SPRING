package controller;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class SimpleDateFormatEx {
	public static void main(String[] args) {
		SimpleDateFormat format
			= new SimpleDateFormat("yyyy-MM-dd");

		String dateStr = "2018-04-12";
		Date d = null;
		try {
			// String to Date
			d = format.parse(dateStr);
		} catch (ParseException e) {
			e.printStackTrace();
		}
		// 원본 Date 형식
		System.out.println("Date Type : " + d);
		
		// Date to String
		System.out.println( format.format(d) );
	}
}


















