package controller;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Scanner;

import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;

import dao.EmpDao;
import dto.Emp;
import mybatis.MyBatisConnectionFactory;

public class EmpEx {
	
	public static void main(String[] args) {
		
		SqlSessionFactory factory = MyBatisConnectionFactory.getSqlSessionFactory();
		SqlSession sqlSession = factory.openSession(true);

		EmpDao dao = sqlSession.getMapper(EmpDao.class);
		
		System.out.println("----- 전체 출력 -----");
		for(Emp e : dao.selectAll()) {
			System.out.println(e);
		}
		System.out.println("---------------------\n");
		
		Emp emp = new Emp();
		emp.setEmpno(7770);
		emp.setEname("Alice");
		emp.setJob("AAAAA");
		emp.setMgr(8880);
		
		System.out.print("Input Date : ");
		String str = new Scanner(System.in).nextLine();
		
		// java.util.Date <-> String 변환하는 클래스
		SimpleDateFormat format
			= new SimpleDateFormat("yyyy-MM-dd");
		
		Date inDate = null;
		try {
			inDate = format.parse(str);
		} catch (ParseException e1) {
			e1.printStackTrace();
		}
		emp.setHiredate(inDate);
//		emp.setHiredate(new Date());
		
		emp.setSal(70);
		emp.setComm(80);
		emp.setDeptno(40);
		
		System.out.println("----- 삽입 정보 -----");
		System.out.println(emp);
		dao.insertEmp(emp);
		System.out.println("---------------------\n");
		
		System.out.println("----- 삽입 확인 -----");
		System.out.println( dao.selectByEmpNo(emp) );
		System.out.println("---------------------\n");
		
		System.out.println("----- 삭제 -----");
		dao.deleteByEmpNo(emp);
		System.out.println("----------------\n");
		
		System.out.println("----- 삭제 확인 -----");
		System.out.println( dao.selectByEmpNo(emp) );
		System.out.println("---------------------\n");

		System.out.println("----- 전체 출력 -----");
		for(Emp e : dao.selectAll()) {
			System.out.println(e);
		}
		System.out.println("---------------------\n");
		
	}
}







