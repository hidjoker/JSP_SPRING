package controller;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Scanner;

import org.apache.ibatis.session.SqlSession;

import dao.EmpDao;
import dto.Emp;
import mybatis.MyBatisConnectionFactory;

public class EmpEx {
	
	public static void main(String[] args) {
		
		// 오라클 DB 컨넥션 얻기
		SqlSession sqlSession
			= MyBatisConnectionFactory
				.getSqlSessionFactory()
				.openSession();
		
		sqlSession.commit(); // 수동 commit

		
		// sqlSession에 SQL 연결하기
		EmpDao EmpDao = sqlSession.getMapper(EmpDao.class);		
		
		while(true) {
			System.out.println("선택해주세요");
			System.out.println("입력:add/출력:select/지우기:del/전체보기:all/종료:exit");
			System.out.print(">>");
			//입력받기
			Scanner sc = new Scanner(System.in);
			Emp emp = new Emp();
			String word = sc.nextLine();
		
			switch(word) {
			
				case "add" :				
					System.out.println("empno : ");
					emp.setEmpno(sc.nextInt());
					sc.skip("\r\n");
					System.out.println("ename : ");
					emp.setEname(sc.nextLine());
					System.out.println("job : ");
					emp.setJob(sc.nextLine());
					System.out.println("mgr : ");
					emp.setMgr(sc.nextInt());
					sc.skip("\r\n");
					System.out.println("Date(yyyy-MM-dd) : ");
					String date = sc.nextLine();
					SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
					Date d = null;
				
					try {
						d = format.parse(date);
					} catch (ParseException e1) {
						e1.printStackTrace();
					}
					
					emp.setHiredate(d);
					System.out.println("sal : ");
					emp.setSal(sc.nextInt());
					sc.skip("\r\n");
					System.out.println("comm : ");
					emp.setComm(sc.nextInt());
					sc.skip("\r\n");
					System.out.println("deptno : ");	
					emp.setDeptno(sc.nextInt());
					sc.skip("\r\n");
					EmpDao.insertEmp(emp);
					System.out.println("입력 완료~");
					break;
				
				case "select" :
				
					System.out.println("empno : ");
					emp.setEmpno(sc.nextInt());
					sc.skip("\r\n");
					Emp selectEmp = EmpDao.selectByEmpNo(emp);
					System.out.println(selectEmp);
				
					break;
			
				case "del" :
				
					System.out.println("empno : ");
					emp.setEmpno(sc.nextInt());
					sc.skip("\r\n");
					EmpDao.deleteByEmpNo(emp);
					System.out.println("삭제완료~");
				
				case "all" :
				
					List<Emp> list2 = EmpDao.selectAll();
					System.out.println("-------------");
					for(Emp e : list2) {
						System.out.println(e);	
					}
					break;			
			
				case "exit" :
					System.out.println("바이!");
					return;					
			}
	

		}
	}
}
