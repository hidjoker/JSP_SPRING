package mvc.controller;

import java.util.HashMap;

import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import mvc.dto.Person;
import mvc.dto.UserVo;

@Controller
public class ParamController {

	private static final Logger logger = LoggerFactory.getLogger(LoginController.class);
	
	
	@RequestMapping(value="/param/test", method=RequestMethod.GET)
	public void paramTest(HttpServletRequest req, Model model
			,@RequestParam UserVo vo) {
		
		req.setAttribute("testData", "hello");
		model.addAttribute("testData2","hi");		
	}
	
	// @RequestMapping에 method를 설정하지 않으면
	// 모든 요청을 다 처리한다
	@RequestMapping(value="/param/requestParam", method=RequestMethod.GET)
	public String paramTest2() {
		return "param/paramForm";
	}
	
	@RequestMapping(value="/param/requestParam", method=RequestMethod.POST)
	public String paramTest3(@RequestParam(
			required=true, defaultValue="abc", value="name")String n, int age, 
			//required 필수입력 설정, defaultValue 초기값, value name값
			Person p, HttpServletRequest req, Model model, @RequestParam HashMap<String, String> map) {
//		req.setAttribute("age", age);
//		req.setAttribute("name", name);
		
		//request.setAttribute()
		model.addAttribute("age",age);
		model.addAttribute("name",n);
		
		logger.info(p.toString());
		model.addAttribute("obj", p);
		
		logger.info("map : "+map.toString());
		model.addAttribute("map",map);
		
		//request.getRequestDispatcher("viewName").forward(...)
		return "param/paramResult";
	}
}
