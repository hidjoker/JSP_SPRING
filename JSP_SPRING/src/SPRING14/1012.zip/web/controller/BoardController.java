package web.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpRequest;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;

import web.dto.Board;
import web.dto.Comment;
import web.dto.File;
import web.dto.Paging;
import web.service.BoardServiceImpl;

@Controller
public class BoardController {
	
	private static Logger logger
		= LoggerFactory.getLogger(BoardController.class);
	
	@Autowired
	private BoardServiceImpl service;
	
	@RequestMapping(value="/board/list", method=RequestMethod.GET)
	public void list(HttpServletRequest req,Model m) {
		
		logger.info("들어옴");
		// 현재 페이지 
		String param = req.getParameter("curPage");
		
		int curPage = 0;
		if( !"".equals(param) && param != null ) {
			curPage = Integer.parseInt(
				req.getParameter("curPage") );
		}
		// 총 게시글 수
		int totalCount = service.totalCnt();
		
		Paging paging = new Paging(totalCount,curPage);
		logger.info("startNo : "+paging.getStartNo());
		logger.info("EndNo : "+paging.getEndNo());
		List<Board> list = service.list(paging);
		m.addAttribute("list",list);	
		m.addAttribute("paging",paging);
	}
	
	@RequestMapping(value="/board/write", method=RequestMethod.GET)
	public void write() {}
	
	@RequestMapping(value="/error/loginErr", method=RequestMethod.GET)
	public void loginErr() {}
	
	@RequestMapping(value="/error/neIdErr", method=RequestMethod.GET)
	public void neIdErr(int boardno,Model m) {
		m.addAttribute("boardno",boardno);
	}
	
	@RequestMapping(value="/board/write", method=RequestMethod.POST)
	public void writeProc(MultipartFile file, Board board, File up, 
			HttpSession session,HttpServletResponse resp) {
		if(file==null) {
			resp.setContentType("text/html;charset=utf-8");

			board.setId(String.valueOf(session.getAttribute("logid")));
			service.write(board);
			
			PrintWriter out=null;
			try {
				out = resp.getWriter();
				out.println("<script>");
				out.println("alert('글쓰기 완료')");
				out.println("location.href='/board/list'");
				out.println("</script>");
				out.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
						
		}else {
			
		}
		
	}
	
	@RequestMapping(value="/board/update", method=RequestMethod.GET)
	public void update(Board board,Model m) {
		Board resBoard = service.view(board);
		m.addAttribute("board", resBoard);		
	}
	
	@RequestMapping(value="/board/update", method=RequestMethod.POST)
	public void updateProc(MultipartFile file, Board board, File up, 
			HttpSession session,HttpServletResponse resp) {
		
		if(file==null) {
			//이전파일 삭제
			//파일 추가
			//내용 수정
			service.updateBoard(board);			
			resp.setContentType("text/html;charset=utf-8");
			PrintWriter out=null;
			try {
				out = resp.getWriter();
				out.println("<script>");
				out.println("alert('글수정 완료')");
				out.println("location.href='/board/view?boardno="+board.getBoardno()+"'");
				out.println("</script>");
				out.close();	
			} catch (IOException e) {
				e.printStackTrace();
			}	
		}	
	}
	
	@RequestMapping(value="/board/delete", method=RequestMethod.GET)
	public void delete(Board board,HttpServletResponse resp) {
		
		//첨부파일 삭제
		//댓글 삭제
		
		//게시글 삭제
		service.deleteBoard(board);
		resp.setContentType("text/html;charset=utf-8");
		PrintWriter out=null;
		try {
			out = resp.getWriter();
			out.println("<script>");
			out.println("alert('글삭제 완료')");
			out.println("location.href='/board/list'");
			out.println("</script>");
			out.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
		
	}
	
	@RequestMapping(value="/board/view", method=RequestMethod.GET)
	public void view(HttpServletRequest req,Model m) {
		int boardno = Integer.valueOf(req.getParameter("boardno"));
		Board board = new Board();
		board.setBoardno(boardno);
		Board resBoard = service.view(board);
		List<Comment> list = service.commentList(board);
		m.addAttribute("board",resBoard);	
		m.addAttribute("comments",list);
	}
	
	@RequestMapping(value="/board/view", method=RequestMethod.POST
			//한글폰트(방법2)
			,produces = "application/json;charset=utf-8")
	public @ResponseBody Map<String,List<Comment>> viewProc(
			Comment comment,Board board) {
		
		if("add".equals(comment.getSort())) {
			logger.info("추가");
			service.commentInsert(comment);
		}else if("del".equals(comment.getSort())) {
			Comment resComment = service.commentByCommentNo(comment);
			if(comment.getPw().equals(resComment.getPw())){
				logger.info("삭제");
				service.commentDelete(comment);
			}else{
				
			}
		}
		
		List<Comment> list = service.commentList(board);
		
		HashMap<String,List<Comment>> map = new HashMap<>();
		map.put("comments",list);

		return map;
	}

		
}
