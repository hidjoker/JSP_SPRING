package web.dao;

import web.dto.Member;

public interface MemberDao {

	public void join(Member member);
	
	public int search(Member member);
	
	public int searchById(Member member);
	
	public Member select(Member member);
	
}
