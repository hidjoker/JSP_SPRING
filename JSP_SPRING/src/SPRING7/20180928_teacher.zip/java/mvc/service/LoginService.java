package mvc.service;

import mvc.dto.Login;

public interface LoginService {

	//로그인 처리
	public boolean login(Login login);

	//회원가입 처리
	public void join(Login login);
	
	//회원정보 조회
	public Login info(String id);
}



















