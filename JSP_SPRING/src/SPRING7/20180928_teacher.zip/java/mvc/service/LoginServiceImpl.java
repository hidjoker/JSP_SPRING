package mvc.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import mvc.dao.LoginDao;
import mvc.dto.Login;

@Service
public class LoginServiceImpl implements LoginService{

	@Autowired LoginDao loginDao;
	
	//로그인 처리
	public boolean login(Login login) {
		if( loginDao.selectCntLogin(login) > 0 ) {
			return true;
			
		} else {
			return false;
			
		}
	}

	@Override
	public void join(Login login) {
		loginDao.insert(login);
	}

	@Override
	public Login info(String id) {
		return loginDao.selectLoginById(id);
	}
	
}
















