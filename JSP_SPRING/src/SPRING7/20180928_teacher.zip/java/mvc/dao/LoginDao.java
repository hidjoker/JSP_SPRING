package mvc.dao;

import mvc.dto.Login;

public interface LoginDao {

	//ID,PW가 일치하는 사람 수 반환
	public int selectCntLogin(Login login);
	
	//회원가입
	public void insert(Login login);
	
	//회원정보 조회
	public Login selectLoginById(String id);
	
}











