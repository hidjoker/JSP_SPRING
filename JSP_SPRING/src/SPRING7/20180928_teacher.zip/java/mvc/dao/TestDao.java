package mvc.dao;

public interface TestDao {
	
	public int select();
	
}
