package mvc.dao;

import java.util.List;

import mvc.dto.Member;

public interface MemberDao {
	
	//전체조회
	public List<Member> list();
	
	//회원가입
	public void insert(Member member);
	
	//회원탈퇴 - 삭제
	public void delete(Member member);
	
}

















