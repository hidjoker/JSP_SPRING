package mvc.dao;

import java.util.HashMap;
import java.util.List;

import mvc.dto.Article;

public interface MyBatisDao {

	public List<Article> select();
	
	public List<Article> select2(HashMap<String,String> map);
	
}
















