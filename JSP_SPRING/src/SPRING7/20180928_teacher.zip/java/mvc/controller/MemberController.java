package mvc.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import mvc.dao.MemberDao;
import mvc.dto.Member;

@Controller
@RequestMapping(value="/user")
public class MemberController {

	private static final Logger logger
		= LoggerFactory.getLogger(MemberController.class);
	
	@Autowired MemberDao memberDao;
	
	@RequestMapping(value="/list")
	public void list(Model model) {
		
		//전체 조회
		List<Member> memberList = memberDao.list();
		
		//조회결과 MODEL로 넣기
		model.addAttribute("memberList", memberList);
		
	}
	
	@RequestMapping(value="/insert", method=RequestMethod.GET)
	public void insertForm() { }
	
	@RequestMapping(value="/insert", method=RequestMethod.POST)
	public String insertProcess(Member member) {
		
//		logger.info(member.toString());
		
		memberDao.insert(member);
		
		return "redirect:/user/list";
	}
	
	@RequestMapping(value="/delete", method=RequestMethod.POST)
	public String deleteProcess(Member delMember) {
		
		logger.info(delMember.toString());
		
		memberDao.delete(delMember);
		
		return "redirect:/user/list";
	}
	
}


















