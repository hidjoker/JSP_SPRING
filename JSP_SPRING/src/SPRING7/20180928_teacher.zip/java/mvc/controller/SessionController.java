package mvc.controller;

import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping(value="/session")
public class SessionController {

	private static final Logger logger
		= LoggerFactory.getLogger(SessionController.class);
	
	@RequestMapping(value="/create")
	public void sessionCreate(HttpSession session) {
		
		session.setAttribute("test1", "Apple");
		session.setAttribute("test2", "Banana");
		
		session.setAttribute("login", true);
		session.setAttribute("loginid", "lacuna");
	}

	@RequestMapping(value="/info")
	public void sessionInfomation() { }

	@RequestMapping(value="/delete")
	public void sessionDelete(HttpSession session) { 
		session.invalidate();
	}

}


















