package mvc.controller;

import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import mvc.dto.Login;
import mvc.service.LoginService;

@Controller
@RequestMapping(value="/login")
public class LoginController {
	
	private static final Logger logger
		= LoggerFactory.getLogger(LoginController.class);
	
	@Autowired LoginService loginService;
	
	@RequestMapping(value="/main", method=RequestMethod.GET)
	public void main() {
		
	}
	
	@RequestMapping(value="/join", method=RequestMethod.GET)
	public void joinForm() {
		
	}

	@RequestMapping(value="/join", method=RequestMethod.POST)
	public String joinProcess(Login login) {
		
		loginService.join(login);
		
//		return "redirect:/login/main";
		return "redirect:main";
	}
	
	@RequestMapping(value="/login", method=RequestMethod.GET)
	public void loginForm() {
		
	}
	
	@RequestMapping(value="/login", method=RequestMethod.POST)
	public String LoginProcess(
			Login login
			, HttpSession session) {
		
		if( loginService.login(login) ) {
			session.setAttribute("login", true);
			session.setAttribute("loginid", login.getId());
		}
		
		return "redirect:/login/main";
	}
	
	@RequestMapping(value="/mypage", method=RequestMethod.GET)
	public void mypage(
			HttpSession session,
			Model model ) {
		
		String id = (String)session.getAttribute("loginid");
		
		model.addAttribute("info", loginService.info(id) );
	}

	
	
	@RequestMapping(value="/logout", method=RequestMethod.GET)
	public String logout(HttpSession session) {
		
		session.invalidate();
		
		return "redirect:/login/main";
	}

}



















