package mvc.controller;

import java.util.HashMap;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import mvc.dao.MyBatisDao;
import mvc.dao.TestDao;
import mvc.dto.Article;

@Controller
public class MyBatisController {

	@Autowired TestDao testDao;
	
	private static final Logger logger
		= LoggerFactory.getLogger(MyBatisController.class);
	
	@RequestMapping(value="/mybatis/test")
	public void test() {
		int num = testDao.select();
		
		logger.info(""+num);
	}
	
	//--------20180928------------
	@Autowired MyBatisDao myBatisDao;

//	CREATE TABLE article (
//		    article_no NUMBER,
//		    article_title VARCHAR2(100)
//	);
	
//	INSERT INTO article VALUES ( 1, 'Alice' );
//	INSERT INTO article VALUES ( 2, 'Bob' );
//	INSERT INTO article VALUES ( 3, 'Clare' );
//	COMMIT;

	@RequestMapping(value="/mybatis/article")
	public void mybatis() {
		List<Article> list = myBatisDao.select();
		
		System.out.println(list);
	}

	@RequestMapping(value="/mybatis/article2")
	public void mybatis2() {
		
		HashMap<String, String> map = new HashMap<>();
		map.put("one", "Alice");
		map.put("two", "Clare");
		
		List<Article> list = myBatisDao.select2( map );
		
		System.out.println(list);
	}

	
}



















