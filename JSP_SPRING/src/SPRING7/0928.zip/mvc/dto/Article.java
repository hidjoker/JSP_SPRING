package mvc.dto;

public class Article {

	private int articleNo;
	private String articleTitle;
	
	@Override
	public String toString() {
		return "Article [articleNo=" + articleNo + ", articleTitle=" + articleTitle + "]";
	}
	public int getArticleNo() {
		return articleNo;
	}
	public void setArticleNo(int articleNo) {
		this.articleNo = articleNo;
	}
	public String getArticleTitle() {
		return articleTitle;
	}
	public void setArticleTitle(String articleTitle) {
		this.articleTitle = articleTitle;
	}
	
}