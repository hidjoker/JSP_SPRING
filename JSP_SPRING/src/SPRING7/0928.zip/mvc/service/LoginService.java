package mvc.service;

import mvc.dto.Login;

public interface LoginService {

	//회원가입
	public void getInsert(Login login);
	
	//회원정보
	public Login getSelect(Login login);
	
	//회원조회 
	public int getSearch(Login login);
		
}
