package mvc.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import mvc.dao.LoginDao;
import mvc.dto.Login;

@Service
public class LoginServiceImpl implements LoginService {
	
	@Autowired LoginDao dao;

	@Override
	public void getInsert(Login login) {
		dao.insert(login);
	}

	@Override
	public Login getSelect(Login login) {
		Login resLogin = dao.select(login);
		return resLogin;
	}

	@Override
	public int getSearch(Login login) {
		int res = dao.search(login);
		return res;
	}
	
	
	
	
}
