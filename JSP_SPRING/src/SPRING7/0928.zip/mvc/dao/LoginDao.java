package mvc.dao;

import mvc.dto.Login;

public interface LoginDao {
	
	//회원가입
	public void insert(Login login);
	
	//회원정보
	public Login select(Login login);
	
	//회원조회
	public int search(Login login);
}
