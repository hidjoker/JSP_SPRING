package mvc.dao;

import java.util.List;

import mvc.dto.Member;

public interface TestDao {

	public int select();
	
	public List<Member> selectMember();
	
}