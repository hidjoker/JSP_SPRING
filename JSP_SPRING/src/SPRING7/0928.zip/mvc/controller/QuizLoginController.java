package mvc.controller;

import java.io.PrintWriter;
import java.io.UnsupportedEncodingException;

import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import mvc.dto.Login;
import mvc.service.LoginServiceImpl;

@Controller
@RequestMapping(value="/quiz")
public class QuizLoginController {
	
	private static Logger logger 
		= LoggerFactory.getLogger(QuizLoginController.class);
	
	@Autowired LoginServiceImpl service;
	
	@RequestMapping(value ="/main")
	public void main() {}
	
	@RequestMapping(value ="/login")
	public void login() {}

	@RequestMapping(value ="/loginProc", method=RequestMethod.POST)
	public void loginProc(Login login, HttpSession session
			,PrintWriter out) {
		int res= 0;
		res= service.getSearch(login);
		System.out.println("res : "+res);
		if(res>0) {
			session.setAttribute("login", true);
			session.setAttribute("logid", login.getId());
			out.println("<script>");
			try {
				out.println(new String(("alert('로그인 성공~!')").getBytes(),"utf-8"));
			} catch (UnsupportedEncodingException e) {
				e.printStackTrace();
			}
			out.println("location.href = '/quiz/main'");
			out.println("</script>");
	
		}else {
			out.println("<script>");
			out.println("alert('login fail')");
			out.println("location.href = '/quiz/main'");
			out.println("</script>");
		}
	}
	
	@RequestMapping(value ="/join")
	public void join() {}
	
	@RequestMapping(value ="/joinProc", method=RequestMethod.POST)
	public void joinProc(Model m,Login login,PrintWriter out) {
		service.getInsert(login);
		out.println("<script>");
		try {
			out.println(new String("alert('회원가입 성공!')".getBytes(), "utf-8"));
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
		}
		out.println("location.href = '/quiz/main'"); 
		out.println("</script>");
	}
	
	@RequestMapping(value ="/logout")
	public String logout(HttpSession session) {		
		session.invalidate();
		return "redirect:/quiz/main";
	}
	
	@RequestMapping(value ="/mypage")
	public void logout(HttpSession session,Login login,Model m) {		
		login.setId((String)session.getAttribute("logid"));
		Login resLogin = service.getSelect(login);
		m.addAttribute("login",resLogin);
	}
}
