package com.spring.www;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class HiController {

	@RequestMapping(value="/hi", method=RequestMethod.GET)
	public String hi(int boardno) {		
		
		return "hello";
		// /WEB-INF/views/hello.jsp
	}
	
	@RequestMapping(value="/login/login", method=RequestMethod.GET)
	public void loginForm() {}
	
	@RequestMapping(value="/test", method=RequestMethod.GET)
	public String testForm() {
		return "viewName";
	}
	
	@RequestMapping(value="/test1", method=RequestMethod.POST)
	public ModelAndView testProcess() {
		
		ModelAndView mav = new ModelAndView(); 
		mav.addObject("data",123); //MODEl 전달값 추가
		mav.setViewName("testView"); //VIEW 지정
		
		return mav;
	}
	
	@RequestMapping(value="/test", method=RequestMethod.POST)
	public String hello() {
		
//		return "hello"; // hello.jsp로 forwarding 발생
		
		// /member/login 으로 redirection 발생
		return "redirect:/member/login";
	}
	
	
}
