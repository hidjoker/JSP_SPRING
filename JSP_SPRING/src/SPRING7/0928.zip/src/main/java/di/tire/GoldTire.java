package di.tire;

public class GoldTire implements Tire{

	@Override
	public String getProduct() {
		return "골드타이어";
	}
	
}
