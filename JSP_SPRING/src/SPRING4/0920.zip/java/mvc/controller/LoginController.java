package mvc.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import mvc.dto.UserVo;

@Controller
//@RequestMapping(value="/hola")
public class LoginController {
	
	private static final Logger logger = LoggerFactory.getLogger(LoginController.class);

	@RequestMapping(value = "/member/login", method = RequestMethod.GET)
	public void login() {
		// VIEW NAME : member/login 
		// VIEW : /WEB-INF/views/ + member/login + .jsp
		// /WEB-INF/views/member/login.jsp
	}
	
	@RequestMapping(value="/member/login"
					, method=RequestMethod.POST)
	public ModelAndView loginProcess(
			String id, String pw, UserVo vo) {
		logger.info("loginProcess() method 호출");
		logger.info("id="+id+", pw="+pw);
		logger.info(vo.toString());
		
		//-----------------------------------
		
		// view에 모델 전달하기 + viewName 지정하기
		ModelAndView mav = new ModelAndView();
		// 모델 지정
		mav.addObject("loginInfo", vo);
		
		// viewName 지정
		mav.setViewName("test/loginResult");
		
		//redirection
//		mav.setViewName("redirect:/login/main");
		
		return mav;
	}
	
	@RequestMapping(value="/login/main",
				method=RequestMethod.GET)
	public String main() {
		logger.info("main method(); STARTED!!");
		return "login/main";
	}
}
