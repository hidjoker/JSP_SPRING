package di.xml;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.FileSystemXmlApplicationContext;

import di.tire.Tire;

public class Person {

	public static void main(String[] args) {
		
		// 어플리케이션 컨텍스트 객체
		ApplicationContext context = null;
		
		// 파일시스템(로컬 하드디스크)에 저장된
		// xml(빈 설정파일)을 읽어서 어플리케이션 컨텍스트에
		// 저장하고 그 내용을 객체로 봔환받는다
		context = new FileSystemXmlApplicationContext(
				"/src/main/java/di/xml/di.xml");
		
		// 스프링 Bean을 이용한 의존성 주입
		Car car = (Car) context.getBean("car");
		
		// 스프링 Bean을 이용하여 gTire 객체를 의존성 주입받고
		// car객체의 setter를 이용하여 gTire를 의존성 주입시킴
		car.setTire((Tire) context.getBean("gTire"));		
		System.out.println(car.getInfo());
		
		Car car2 = (Car) context.getBean("car");
		car2.setTire((Tire) context.getBean("sTire"));
		System.out.println(car.getInfo());
		
		System.out.println("---------------");
		System.out.println("car : " + car);
		System.out.println("car2 : " + car2);
		System.out.println("---------------");
		System.out.println("car Info : " + car.getInfo());
		System.out.println("car2 Info : "+ car2.getInfo());
		System.out.println("----------------");
		
	}
	
}
