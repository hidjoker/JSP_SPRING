package winwin.service;

import java.util.List;

import org.springframework.stereotype.Service;

import winwin.dto.JobopenBasic;
import winwin.dto.JobopenDetail;

@Service
public class JobopenServiceImpl implements JobopenService {

	@Override
	public void writeBasic(JobopenBasic jobopenBasic) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void writeDetail(JobopenDetail jobopenDetail) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public List<JobopenDetail> selectDetail(JobopenDetail jobopenDetail) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void updateBasic(JobopenBasic jobopenBasic) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public JobopenBasic viewBasic(JobopenBasic jobopenBasic) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public JobopenDetail viewDetail(JobopenDetail jobopenDetail) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void deleteJobOpen(JobopenBasic jobopenBasic) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public int CountBasic() {
		// TODO Auto-generated method stub
		return 0;
	}

}
