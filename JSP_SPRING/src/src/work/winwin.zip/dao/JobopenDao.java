package winwin.dao;

public interface JobopenDao {

}
