package winwin.dao;

public interface ChartDao {

	public int ages20Cho();
	public int ages20Hu();
	public int ages30s();
	public int ages40s();
	
	public int eduHigh();
	public int eduColl();
	public int eduUniv();
	public int eduMD();
	
	public int first_16();
	public int second_16();
	public int first_17();
	public int second_17();
	public int first_18();
	public int second_18();
	
}
