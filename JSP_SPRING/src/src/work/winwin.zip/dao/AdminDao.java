package winwin.dao;

import winwin.dto.Admin;

public interface AdminDao {

	public void adminlogin(Admin admin);

}
